$(function(e) {
	$('#example').DataTable();
} );
$(document).ready(function() {
	$('#example2').DataTable();
} );