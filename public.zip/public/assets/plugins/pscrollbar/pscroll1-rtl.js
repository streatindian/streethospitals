(function($) {
	"use strict";	
	// ______________ PerfectScrollbar	
	const ps1 = new PerfectScrollbar('.content', {
		useBothWheelAxes:false,
		suppressScrollX:false,
	});
	
	// ______________ PerfectScrollbar	
	const ps2 = new PerfectScrollbar('.content1', {
		useBothWheelAxes:false,
		suppressScrollX:false,
	});
	
})(jQuery);