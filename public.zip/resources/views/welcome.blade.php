<!DOCTYPE html>
<html class="no-js" lang="en">

<head>

    <meta charset="UTF-8">
    <meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=0'>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Medz - Medical Directory HTML Template">
    <meta name="author" content="Spruko Technologies Private Limited">
    <meta name="keywords"
        content="appointments, booking, bootstrap list template,  directory listing html template,  directory website template, doctor directory, doctor search, health template, healthcare directory, hospital,  html css templates, html directory listing, listing, medical bootstrap template, medical directory, medical html template , medical template,  medical web templates, medical website templates, pharma website templates, responsive html template,template html css, online directory website,  html5 template, themeforest html,  online directory, simple html templates ">

    <!-- Favicon -->
    <link rel="icon" href="{{ asset('assets/images/brand/favicon.ico') }}" type="image/x-icon" />
    <link rel="shortcut icon" type="image/x-icon" href="{{ asset('assets/images/brand/favicon.ico') }}" />

    <!-- Title -->
    <title>Medz - Medical Directory HTML Template</title>

    <!-- Bootstrap Css -->
    <link href="{{ asset('assets/plugins/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">

    <!-- Style Css -->
    <link href="{{ asset('assets/css/style.css') }}" rel="stylesheet">

    <!--Icons  Css -->
    <link href="{{ asset('assets/css/icons.css') }}" rel="stylesheet">

    <!--Select2 Css -->
    <link href="{{ asset('assets/plugins/select2/select2.min.css') }}" rel="stylesheet">

    <!-- Owl Theme css-->
    <link href="{{ asset('assets/plugins/owl-carousel/owl.carousel.css') }}" rel="stylesheet">

    <!-- Date Picker Css -->
    <link href="{{ asset('assets/plugins/date-picker/spectrum.css') }}" rel="stylesheet" />

    <!-- Custom scroll bar css-->
    <link href="{{ asset('assets/plugins/scroll-bar/jquery.mCustomScrollbar.css') }}" rel="stylesheet">

    <!--Color-Skin Css -->
    <link href="{{ asset('assets/color-skins/color10.css') }}" id="theme" media="all" rel="stylesheet">

</head>

<body>

    <!--Loader-->
    <div id="global-loader">
        <img alt="" class="loader-img" src="{{ asset('assets/images/loader.svg') }}">
    </div>
    <!--/Loader-->

    <!-- Header-main -->
    <div class="header-main">

        <!-- Top Bar -->
        <div class="top-bar">
            <div class="container">
                <div class="row">
                    <div class="col-xl-8 col-lg-8 col-sm-4 col-7">
                        <div class="top-bar-left d-flex">
                            <div class="clearfix">
                                <ul class="socials">
                                    <li>
                                        <a class="social-icon text-dark" href="#"><i
                                                class="fa fa-facebook"></i></a>
                                    </li>
                                    <li>
                                        <a class="social-icon text-dark" href="#"><i
                                                class="fa fa-twitter"></i></a>
                                    </li>
                                    <li>
                                        <a class="social-icon text-dark" href="#"><i
                                                class="fa fa-linkedin"></i></a>
                                    </li>
                                    <li>
                                        <a class="social-icon text-dark" href="#"><i
                                                class="fa fa-google-plus"></i></a>
                                    </li>
                                </ul>
                            </div>
                            <div class="clearfix">
                                <ul class="contact">
                                    <li class="d-lg-none">
                                        <a class="callnumber text-dark" href="#"><span><i
                                                    class="fa fa-phone"></i>: +425 345 8765</span></a>
                                    </li>
                                    <li class="select-country">
                                        <select class="form-control select2-flag-search"
                                            data-placeholder="Select Country">
                                            <option value="UM">
                                                United States of America
                                            </option>
                                            <option value="AF">
                                                Afghanistan
                                            </option>
                                            <option value="AL">
                                                Albania
                                            </option>
                                            <option value="AD">
                                                Andorra
                                            </option>
                                            <option value="AG">
                                                Antigua and Barbuda
                                            </option>
                                            <option value="AU">
                                                Australia
                                            </option>
                                            <option value="AM">
                                                Armenia
                                            </option>
                                            <option value="AO">
                                                Angola
                                            </option>
                                            <option value="AR">
                                                Argentina
                                            </option>
                                            <option value="AT">
                                                Austria
                                            </option>
                                            <option value="AZ">
                                                Azerbaijan
                                            </option>
                                            <option value="BA">
                                                Bosnia and Herzegovina
                                            </option>
                                            <option value="BB">
                                                Barbados
                                            </option>
                                            <option value="BD">
                                                Bangladesh
                                            </option>
                                            <option value="BE">
                                                Belgium
                                            </option>
                                            <option value="BF">
                                                Burkina Faso
                                            </option>
                                            <option value="BG">
                                                Bulgaria
                                            </option>
                                            <option value="BH">
                                                Bahrain
                                            </option>
                                            <option value="BJ">
                                                Benin
                                            </option>
                                            <option value="BN">
                                                Brunei
                                            </option>
                                            <option value="BO">
                                                Bolivia
                                            </option>
                                            <option value="BT">
                                                Bhutan
                                            </option>
                                            <option value="BY">
                                                Belarus
                                            </option>
                                            <option value="CD">
                                                Congo
                                            </option>
                                            <option value="CA">
                                                Canada
                                            </option>
                                            <option value="CF">
                                                Central African Republic
                                            </option>
                                            <option value="CI">
                                                Cote d'Ivoire
                                            </option>
                                            <option value="CL">
                                                Chile
                                            </option>
                                            <option value="CM">
                                                Cameroon
                                            </option>
                                            <option value="CN">
                                                China
                                            </option>
                                            <option value="CO">
                                                Colombia
                                            </option>
                                            <option value="CU">
                                                Cuba
                                            </option>
                                            <option value="CV">
                                                Cabo Verde
                                            </option>
                                            <option value="CY">
                                                Cyprus
                                            </option>
                                            <option value="DJ">
                                                Djibouti
                                            </option>
                                            <option value="DK">
                                                Denmark
                                            </option>
                                            <option value="DM">
                                                Dominica
                                            </option>
                                            <option value="DO">
                                                Dominican Republic
                                            </option>
                                            <option value="EC">
                                                Ecuador
                                            </option>
                                            <option value="EE">
                                                Estonia
                                            </option>
                                            <option value="ER">
                                                Eritrea
                                            </option>
                                            <option value="ET">
                                                Ethiopia
                                            </option>
                                            <option value="FI">
                                                Finland
                                            </option>
                                            <option value="FJ">
                                                Fiji
                                            </option>
                                            <option value="FR">
                                                France
                                            </option>
                                            <option value="GA">
                                                Gabon
                                            </option>
                                            <option value="GD">
                                                Grenada
                                            </option>
                                            <option value="GE">
                                                Georgia
                                            </option>
                                            <option value="GH">
                                                Ghana
                                            </option>
                                            <option value="GH">
                                                Ghana
                                            </option>
                                            <option value="HN">
                                                Honduras
                                            </option>
                                            <option value="HT">
                                                Haiti
                                            </option>
                                            <option value="HU">
                                                Hungary
                                            </option>
                                            <option value="ID">
                                                Indonesia
                                            </option>
                                            <option value="IE">
                                                Ireland
                                            </option>
                                            <option value="IL">
                                                Israel
                                            </option>
                                            <option value="IN">
                                                India
                                            </option>
                                            <option value="IQ">
                                                Iraq
                                            </option>
                                            <option value="IR">
                                                Iran
                                            </option>
                                            <option value="IS">
                                                Iceland
                                            </option>
                                            <option value="IT">
                                                Italy
                                            </option>
                                            <option value="JM">
                                                Jamaica
                                            </option>
                                            <option value="JO">
                                                Jordan
                                            </option>
                                            <option value="JP">
                                                Japan
                                            </option>
                                            <option value="KE">
                                                Kenya
                                            </option>
                                            <option value="KG">
                                                Kyrgyzstan
                                            </option>
                                            <option value="KI">
                                                Kiribati
                                            </option>
                                            <option value="KW">
                                                Kuwait
                                            </option>
                                            <option value="KZ">
                                                Kazakhstan
                                            </option>
                                            <option value="LA">
                                                Laos
                                            </option>
                                            <option value="LB">
                                                Lebanons
                                            </option>
                                            <option value="LI">
                                                Liechtenstein
                                            </option>
                                            <option value="LR">
                                                Liberia
                                            </option>
                                            <option value="LS">
                                                Lesotho
                                            </option>
                                            <option value="LT">
                                                Lithuania
                                            </option>
                                            <option value="LU">
                                                Luxembourg
                                            </option>
                                            <option value="LV">
                                                Latvia
                                            </option>
                                            <option value="LY">
                                                Libya
                                            </option>
                                            <option value="MA">
                                                Morocco
                                            </option>
                                            <option value="MC">
                                                Monaco
                                            </option>
                                            <option value="MD">
                                                Moldova
                                            </option>
                                            <option value="ME">
                                                Montenegro
                                            </option>
                                            <option value="MG">
                                                Madagascar
                                            </option>
                                            <option value="MH">
                                                Marshall Islands
                                            </option>
                                            <option value="MK">
                                                Macedonia (FYROM)
                                            </option>
                                            <option value="ML">
                                                Mali
                                            </option>
                                            <option value="MM">
                                                Myanmar (formerly Burma)
                                            </option>
                                            <option value="MN">
                                                Mongolia
                                            </option>
                                            <option value="MR">
                                                Mauritania
                                            </option>
                                            <option value="MT">
                                                Malta
                                            </option>
                                            <option value="MV">
                                                Maldives
                                            </option>
                                            <option value="MW">
                                                Malawi
                                            </option>
                                            <option value="MX">
                                                Mexico
                                            </option>
                                            <option value="MZ">
                                                Mozambique
                                            </option>
                                            <option value="NA">
                                                Namibia
                                            </option>
                                            <option value="NG">
                                                Nigeria
                                            </option>
                                            <option value="NO">
                                                Norway
                                            </option>
                                            <option value="NP">
                                                Nepal
                                            </option>
                                            <option value="NR">
                                                Nauru
                                            </option>
                                            <option value="NZ">
                                                New Zealand
                                            </option>
                                            <option value="OM">
                                                Oman
                                            </option>
                                            <option value="PA">
                                                Panama
                                            </option>
                                            <option value="PF">
                                                Paraguay
                                            </option>
                                            <option value="PG">
                                                Papua New Guinea
                                            </option>
                                            <option value="PH">
                                                Philippines
                                            </option>
                                            <option value="PK">
                                                Pakistan
                                            </option>
                                            <option value="PL">
                                                Poland
                                            </option>
                                            <option value="QA">
                                                Qatar
                                            </option>
                                            <option value="RO">
                                                Romania
                                            </option>
                                            <option value="RU">
                                                Russia
                                            </option>
                                            <option value="RW">
                                                Rwanda
                                            </option>
                                            <option value="SA">
                                                Saudi Arabia
                                            </option>
                                            <option value="SB">
                                                Solomon Islands
                                            </option>
                                            <option value="SC">
                                                Seychelles
                                            </option>
                                            <option value="SD">
                                                Sudan
                                            </option>
                                            <option value="SE">
                                                Sweden
                                            </option>
                                            <option value="SG">
                                                Singapore
                                            </option>
                                            <option value="TG">
                                                Togo
                                            </option>
                                            <option value="TH">
                                                Thailand
                                            </option>
                                            <option value="TJ">
                                                Tajikistan
                                            </option>
                                            <option value="TL">
                                                Timor-Leste
                                            </option>
                                            <option value="TM">
                                                Turkmenistan
                                            </option>
                                            <option value="TN">
                                                Tunisia
                                            </option>
                                            <option value="TO">
                                                Tonga
                                            </option>
                                            <option value="TR">
                                                Turkey
                                            </option>
                                            <option value="TT">
                                                Trinidad and Tobago
                                            </option>
                                            <option value="TW">
                                                Taiwan
                                            </option>
                                            <option value="UA">
                                                Ukraine
                                            </option>
                                            <option value="UG">
                                                Uganda
                                            </option>
                                            <option value="UY">
                                                Uruguay
                                            </option>
                                            <option value="UZ">
                                                Uzbekistan
                                            </option>
                                            <option value="VA">
                                                Vatican City (Holy See)
                                            </option>
                                            <option value="VE">
                                                Venezuela
                                            </option>
                                            <option value="VN">
                                                Vietnam
                                            </option>
                                            <option value="VU">
                                                Vanuatu
                                            </option>
                                            <option value="YE">
                                                Yemen
                                            </option>
                                            <option value="ZM">
                                                Zambia
                                            </option>
                                            <option value="ZW">
                                                Zimbabwe
                                            </option>
                                        </select>
                                    </li>
                                    <li class="dropdown">
                                        <a class="text-dark" data-toggle="dropdown" href="#"><span>Language <i
                                                    class="fa fa-caret-down text-muted"></i></span></a>
                                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                            <a class="dropdown-item" href="#">English</a>
                                            <a class="dropdown-item" href="#">Arabic</a>
                                            <a class="dropdown-item" href="#">German</a>
                                            <a class="dropdown-item" href="#">Greek</a>
                                            <a class="dropdown-item" href="#">Vehiclenish</a>
                                        </div>
                                    </li>
                                    <li class="dropdown">
                                        <a class="text-dark" data-toggle="dropdown" href="#"><span>Currency <i
                                                    class="fa fa-caret-down text-muted"></i></span></a>
                                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                            <a class="dropdown-item" href="#">USD</a>
                                            <a class="dropdown-item" href="#">EUR</a>
                                            <a class="dropdown-item" href="#">INR</a>
                                            <a class="dropdown-item" href="#">GBP</a>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-sm-8 col-5">
                        <div class="top-bar-right">
                            <ul class="custom">
                                <li>
                                    <a class="text-dark" href="register.html"><i class="fa fa-user mr-1"></i>
                                        <span>Register</span></a>
                                </li>
                                <li>
                                    <a class="text-dark" href="login.html"><i class="fa fa-sign-in mr-1"></i>
                                        <span>Login</span></a>
                                </li>
                                <li class="dropdown">
                                    <a class="text-dark" data-toggle="dropdown" href="#"><i
                                            class="fa fa-home mr-1"></i> <span>My Dashboard</span></a>
                                    <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                        <a class="dropdown-item" href="mydash.html"><i
                                                class="dropdown-icon icon icon-user"></i> My Profile</a>
                                        <a class="dropdown-item" href="#"><i
                                                class="dropdown-icon icon icon-speech"></i> Inbox</a>
                                        <a class="dropdown-item" href="#"><i
                                                class="dropdown-icon icon icon-bell"></i> Notifications</a>
                                        <a class="dropdown-item" href="mydash.html"><i
                                                class="dropdown-icon icon icon-settings"></i> Account Settings</a>
                                        <a class="dropdown-item" href="#"><i
                                                class="dropdown-icon icon icon-power"></i> Log out</a>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--/Top Bar-->

        <!--Header Search-->
        <header class="header-search border-bottom p-2 bg-white">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-12">
                        <div class="header-search-logo d-none d-lg-block">
                            <a class="header-logo header-brand-img" href="{{url('/')}}"></a>
                        </div>
                    </div>
                    <div class="col-lg-9 col-md-12 header-support">
                        <ul class="hor-support float-right">
                            <li class="support-header">
                                <a href="#">
                                    <i class="fa fa-phone"></i>
                                    <div class="support-text">
                                        <h6>+68 872-627-9735</h6>
                                        <p>24/7 available services </p>
                                    </div>
                                </a>
                            </li>
                            <li class="support-header">
                                <a href="#">
                                    <i class="fa fa-envelope"></i>
                                    <div class="support-text">
                                        <h6>support@yourdomain.com</h6>
                                        <p>Ask For any questions</p>
                                    </div>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </header>
        <!--/Header Search-->

        <!-- Horizontal Header -->
        <div class="horizontal-header clearfix">
            <div class="container">
                <a class="animated-arrow" id="horizontal-navtoggle"><span></span></a>
                <a class="smllogo mobile-logo" href="{{url('/')}}"></a>
                <a class="callusbtn" href="tel:245-6325-3256"><i aria-hidden="true" class="fa fa-phone"></i></a>
            </div>
        </div>
        <!-- /Horizontal Header -->

        <!-- Horizontal Menu -->
        <div class="sticky">
            <div class="header-style horizontal-main clearfix">
                <div class="horizontal-mainwrapper container clearfix">
                    <nav class="horizontalMenu clearfix d-md-flex">
                        <ul class="horizontalMenu-list">
                            <li aria-haspopup="true">
                                <a class="active" href="#">Home <span class="fe fe-chevron-down"></span></a>
                                <ul class="sub-menu">
                                    <li aria-haspopup="true"><a href="{{url('/')}}">Home-Default</a></li>
                                    <li aria-haspopup="true"><a href="index-text.html">Home Text</a></li>
                                    <li aria-haspopup="true"><a href="index-slides.html">Home Slides</a></li>
                                    <li aria-haspopup="true"><a href="index-video.html">Home Video</a></li>
                                    <li aria-haspopup="true"><a href="index-animation.html">Home Animation</a></li>
                                    <li aria-haspopup="true"><a href="index-map.html">Home Map</a></li>
                                    <li aria-haspopup="true"><a href="index-intro-page.html">Home Intro Page</a></li>
                                    <li aria-haspopup="true"><a href="index-popup-login.html">Home Pop-up login</a>
                                    </li>
                                    <li aria-haspopup="true"><a href="index-banner.html">Home Banner</a></li>
                                </ul>
                            </li>
                            <li aria-haspopup="true">
                                <a href="about.html">About Us</a>
                            </li>
                            <li aria-haspopup="true">
                                <a href="widgets.html">Widgets</a>
                            </li>
                            <li aria-haspopup="true">
                                <a href="#">Pages <span class="fe fe-chevron-down"></span></a>
                                <div class="horizontal-megamenu clearfix">
                                    <div class="container">
                                        <div class="megamenu-content">
                                            <div class="row">
                                                <ul class="col link-list">
                                                    <li class="title">Listing pages</li>
                                                    <li><a href="page-list.html">Page List</a></li>
                                                    <li><a href="page-list-right.html">Page List Right</a></li>
                                                    <li><a href="page-list-map.html">Page Map List</a></li>
                                                    <li><a href="page-list-map2.html">Page Map List 02</a></li>
                                                    <li><a href="page-list-map3.html">Page Map List 03</a></li>
                                                </ul>
                                                <ul class="col link-list">
                                                    <li class="title">Other pages</li>
                                                    <li><a href="ad-posts.html">Ad Posts</a></li>
                                                    <li><a href="edit-posts.html">Edit Posts</a></li>
                                                    <li><a href="ad-posts2.html">Ad Posts2</a></li>
                                                    <li><a href="edit-posts2.html">Edit Posts2</a></li>
                                                    <li><a href="pricing.html">Pricing</a></li>
                                                    <li><a href="typography.html">Typography</a></li>
                                                    <li><a href="categories.html">Categories</a></li>
                                                    <li><a href="testimonial.html">Testimonial</a></li>
                                                    <li><a href="inovice.html">Invoice</a></li>
                                                </ul>
                                                <ul class="col link-list">
                                                    <li class="title">User pages</li>
                                                    <li><a href="userprofile.html">User Profile</a> </li>
                                                    <li><a href="userprofile2.html">User Profile 2</a></li>
                                                    <li><a href="mydash.html">My Dashboard</a></li>
                                                    <li><a href="myads.html">Ads</a></li>
                                                    <li><a href="myfavorite.html">Favorite Ads</a></li>
                                                    <li><a href="settings.html">Settings</a></li>
                                                    <li><a href="tips.html">Tips</a></li>
                                                </ul>
                                                <ul class="col link-list">
                                                    <li class="title">User pages</li>
                                                    <li><a href="manged.html">Manged Ads</a></li>
                                                    <li><a href="payments.html">Payments</a></li>
                                                    <li><a href="orders.html">Orders</a></li>
                                                    <li><a href="faq.html">Faq</a></li>
                                                    <li><a href="usersall.html">User Lists</a></li>
                                                </ul>
                                                <ul class="col link-list">
                                                    <li class="title">Headers & Footer Pages</li>
                                                    <li><a href="header-style1.html">Header Style 01</a></li>
                                                    <li><a href="header-style2.html">Header Style 02</a></li>
                                                    <li><a href="header-style3.html">Header Style 03</a></li>
                                                    <li><a href="header-style4.html">Header Style 04</a></li>
                                                    <li><a href="footer-style.html">Footer Style 01</a></li>
                                                    <li><a href="footer-style2.html">Footer Style 02</a></li>
                                                    <li><a href="footer-style3.html">Footer Style 03</a></li>
                                                    <li><a href="footer-style4.html">Footer Style 04</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li aria-haspopup="true">
                                <a href="#">Categories <span class="fe fe-chevron-down"></span></a>
                                <ul class="sub-menu">
                                    <li aria-haspopup="true">
                                        <a href="#">Hospitals <i
                                                class="fa fa-angle-right float-right mt-1 d-none d-lg-block"></i></a>
                                        <ul class="sub-menu">
                                            <li><a href="hospitals-list.html">Hospital List</a></li>
                                            <li><a href="hospitals-list-right.html">Hospital List Right</a></li>
                                            <li><a href="hospital-details.html">Hospital Details</a></li>
                                            <li><a href="hospital-details-02.html">Hospital Details 02</a></li>
                                            <li><a href="hospital-details-right.html">Hospital Details Right</a></li>
                                        </ul>
                                    </li>
                                    <li aria-haspopup="true">
                                        <a href="#">Doctors <i
                                                class="fa fa-angle-right float-right mt-1 d-none d-lg-block"></i></a>
                                        <ul class="sub-menu">
                                            <li><a href="doctors-list.html">Doctors List</a></li>
                                            <li><a href="doctors-list-right.html">Doctors List Right</a></li>
                                            <li><a href="doctor-details.html">Doctor Details</a></li>
                                            <li><a href="doctor-details2.html">Doctor Details 2</a></li>
                                            <li><a href="doctor-details-right.html">Doctor Details Right</a></li>
                                        </ul>
                                    </li>
                                    <li aria-haspopup="true">
                                        <a href="#">FitnessCenter<i
                                                class="fa fa-angle-right float-right mt-1 d-none d-lg-block"></i></a>
                                        <ul class="sub-menu">
                                            <li><a href="fitness-list.html">Fitness List</a></li>
                                            <li><a href="fitness-list-right.html">Fitness List Right</a></li>
                                            <li><a href="fitness-details.html">Fitness Details</a></li>
                                            <li><a href="fitness-details2.html">Fitness Details02</a></li>
                                            <li><a href="fitness-details-right.html">Fitness Details Right</a></li>
                                        </ul>
                                    </li>
                                    <li aria-haspopup="true">
                                        <a href="#">Pharmacy<i
                                                class="fa fa-angle-right float-right mt-1 d-none d-lg-block"></i></a>
                                        <ul class="sub-menu">
                                            <li><a href="pharmacy-list.html">Pharmacy List</a></li>
                                            <li><a href="pharmacy-list-right.html">Pharmacy List Right</a></li>
                                            <li><a href="pharmacy-details.html">Pharmacy Details</a></li>
                                            <li><a href="pharmacy-details2.html">Pharmacy Details02</a></li>
                                            <li><a href="pharmacy-details-right.html">Pharmacy Details Right</a></li>
                                        </ul>
                                    </li>
                                    <li aria-haspopup="true">
                                        <a href="#">BloodBank<i
                                                class="fa fa-angle-right float-right mt-1 d-none d-lg-block"></i></a>
                                        <ul class="sub-menu">
                                            <li><a href="bloodbank-list.html">BloodBank List</a></li>
                                            <li><a href="bloodbank-list-right.html">BloodBank List Right</a></li>
                                            <li><a href="bloodbank-details.html">BloodBank Details</a></li>
                                            <li><a href="bloodbank-details-right.html">BloodBank Details Right</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                            <li aria-haspopup="true">
                                <a href="#">Custom Pages <span class="fe fe-chevron-down"></span></a>
                                <ul class="sub-menu">
                                    <li><a href="register.html">Register</a></li>
                                    <li><a href="login.html">Login</a></li>
                                    <li><a href="login-2.html">Login 02</a></li>
                                    <li><a href="forgot.html">Forgot Password</a></li>
                                    <li><a href="lockscreen.html">Lock Screen</a></li>
                                    <li><a href="underconstruction.html">UnderConstruction</a></li>
                                    <li><a href="404.html">404</a></li>
                                </ul>
                            </li>
                            <li aria-haspopup="true">
                                <a href="#">Blog <span class="fe fe-chevron-down"></span></a>
                                <ul class="sub-menu">
                                    <li aria-haspopup="true">
                                        <a href="#">Blog Grid <i
                                                class="fa fa-angle-right float-right mt-1 d-none d-lg-block"></i></a>
                                        <ul class="sub-menu">
                                            <li><a href="blog-grid.html">Blog Grid Left</a></li>
                                            <li><a href="blog-grid-right.html">Blog Grid Right</a></li>
                                            <li><a href="blog-grid-center.html">Blog Grid Center</a></li>
                                        </ul>
                                    </li>
                                    <li aria-haspopup="true">
                                        <a href="#">Blog List <i
                                                class="fa fa-angle-right float-right mt-1 d-none d-lg-block"></i></a>
                                        <ul class="sub-menu">
                                            <li><a href="blog-list.html">Blog List Left</a></li>
                                            <li><a href="blog-list-right.html">Blog List Right</a></li>
                                            <li><a href="blog-list-center.html">Blog List Center</a></li>
                                        </ul>
                                    </li>
                                    <li aria-haspopup="true">
                                        <a href="#">Blog Details <i
                                                class="fa fa-angle-right float-right mt-1 d-none d-lg-block"></i></a>
                                        <ul class="sub-menu">
                                            <li><a href="blog-details.html">Blog Details Left</a></li>
                                            <li><a href="blog-details-right.html">Blog Details Right</a></li>
                                            <li><a href="blog-details-center.html">Blog Details Center</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                            <li aria-haspopup="true">
                                <a href="contact.html">Contact Us </a>
                            </li>
                            <li aria-haspopup="true" class="d-lg-none mt-5 pb-5 mt-lg-0">
                                <span>
                                    <a href="ad-posts.html" class="btn btn-secondary btn-block mb-lg-0"><i
                                            class="icon icon-plus mr-1 text-white"></i>Add Your Post</a>
                                </span>
                            </li>
                        </ul>
                        <ul class="mb-0">
                            <li aria-haspopup="true" class="d-none d-lg-block ">
                                <span>
                                    <a href="ad-posts.html" class="btn btn-danger btn-block mb-lg-0"><i
                                            class="fe fe-plus-circle mr-1 text-white"></i>Add Your Post</a>
                                </span>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        <!-- /Horizontal Menu -->

    </div>
    <!-- /Header-main -->

    <!--Section-->
    <section>
        <div class="banner-2 cover-image sptb-2 sptb-tab bg-background2 banner-section"
            data-image-src="{{ asset('assets/images/banners/banner1.jpg') }}">
            <div class="header-text mb-0">
                <div class="container">
                    <div class="text-center text-white">
                        <h1 class="mb-1">Find the Nearest Medical Facility</h1>
                        <p>It is a long established fact that a reader will be distracted by the when looking at its
                            layout.</p>
                    </div>
                    <div class="row">
                        <div class="col-xl-10 col-lg-12 col-md-12 d-block mx-auto">
                            <div class="item-search-tabs">
                                <div class="item-search-menu">
                                    <ul class="nav">
                                        <li class="">
                                            <a class="active" data-toggle="tab" href="#tab1">Hospitals</a>
                                        </li>
                                        <li>
                                            <a data-toggle="tab" href="#tab2">Doctors</a>
                                        </li>
                                        <li>
                                            <a data-toggle="tab" href="#tab3">FitnesCenters</a>
                                        </li>
                                        <li>
                                            <a data-toggle="tab" href="#tab4">Pharmacies</a>
                                        </li>
                                        <li>
                                            <a data-toggle="tab" href="#tab5">Clinics</a>
                                        </li>
                                        <li>
                                            <a data-toggle="tab" href="#tab6">Blood Banks</a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="tab-content index-search-select">
                                    <div class="tab-pane active" id="tab1">
                                        <div class="search-background">
                                            <div class="form row no-gutters">
                                                <div class="form-group col-xl-4 col-lg-4 col-md-12 mb-0 location">
                                                    <input class="form-control border" placeholder="Search Location"
                                                        type="text">
                                                    <span><i class="fa fa-crosshairs  location-gps mr-1"></i></span>
                                                </div>
                                                <div class="form-group col-xl-2 col-lg-2 col-md-12 mb-0">
                                                    <select
                                                        class="form-control select2-show-search border-bottom-0 w-100"
                                                        data-placeholder="Select">
                                                        <optgroup label="Categories">
                                                            <option>
                                                                Type Of Hospitals
                                                            </option>
                                                            <option value="1">
                                                                Women's hospitals
                                                            </option>
                                                            <option value="2">
                                                                Children's hospitals
                                                            </option>
                                                            <option value="4">
                                                                Cardiac hospitals.
                                                            </option>
                                                            <option value="5">
                                                                Cancer Hosptals
                                                            </option>
                                                            <option value="5">
                                                                Diagnostic centers
                                                            </option>
                                                        </optgroup>
                                                    </select>
                                                </div>
                                                <div class="form-group col-xl-2 col-lg-2 col-md-12 mb-0">
                                                    <select
                                                        class="form-control select2-show-search border-bottom-0 w-100"
                                                        data-placeholder="Select">
                                                        <optgroup label="">
                                                            <option>
                                                                Distance
                                                            </option>
                                                            <option value="1">
                                                                3km
                                                            </option>
                                                            <option value="2">
                                                                6km
                                                            </option>
                                                            <option value="3">
                                                                9km
                                                            </option>
                                                            <option value="4">
                                                                10km
                                                            </option>
                                                            <option value="5">
                                                                20km
                                                            </option>
                                                        </optgroup>
                                                    </select>
                                                </div>
                                                <div class="form-group col-xl-2 col-lg-2 col-md-12 mb-0">
                                                    <select
                                                        class="form-control select2-show-search border-bottom-0 w-100"
                                                        data-placeholder="Select">
                                                        <optgroup label="Categories">
                                                            <option>
                                                                Max Fees
                                                            </option>
                                                            <option value="1">
                                                                $10k
                                                            </option>
                                                            <option value="2">
                                                                $10k-$20K
                                                            </option>
                                                            <option value="3">
                                                                $20K-$30K
                                                            </option>
                                                            <option value="4">
                                                                $30K-$40K
                                                            </option>
                                                            <option value="5">
                                                                $40K-$50K
                                                            </option>
                                                            <option value="6">
                                                                $50K-$60K
                                                            </option>
                                                            <option value="7">
                                                                $60K-$70K
                                                            </option>
                                                            <option value="8">
                                                                $70k-$80K
                                                            </option>
                                                            <option value="9">
                                                                $80K &lt; Above
                                                            </option>
                                                        </optgroup>
                                                    </select>
                                                </div>
                                                <div class="form-group col-xl-2 col-lg-2 col-md-12 mb-0">
                                                    <a class="btn btn-block btn-orange fs-14" href="#"><i
                                                            class="fa fa-search"></i> Search</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane" id="tab2">
                                        <div class="search-background">
                                            <div class="form row no-gutters">
                                                <div class="form-group col-xl-4 col-lg-4 col-md-12 mb-0 location">
                                                    <div class="form-group mb-0">
                                                        <input class="form-control border"
                                                            placeholder="Search Location" type="text"> <span><i
                                                                class="fa fa-crosshairs  location-gps mr-1"></i></span>
                                                    </div>
                                                </div>
                                                <div class="form-group col-xl-2 col-lg-2 col-md-12 mb-0">
                                                    <select
                                                        class="form-control select2-show-search border-bottom-0 w-100"
                                                        data-placeholder="Select">
                                                        <optgroup label="Categories">
                                                            <option>
                                                                Type Of Doctors
                                                            </option>
                                                            <option value="1">
                                                                Dentist
                                                            </option>
                                                            <option value="2">
                                                                Gynecologist
                                                            </option>
                                                            <option value="4">
                                                                Physiotherapist
                                                            </option>
                                                            <option value="5">
                                                                Neurosurgeon
                                                            </option>
                                                            <option value="5">
                                                                Neurologist
                                                            </option>
                                                            <option value="5">
                                                                Infertility Specialist
                                                            </option>
                                                            <option value="5">
                                                                Cardiologist
                                                            </option>
                                                        </optgroup>
                                                    </select>
                                                </div>
                                                <div class="form-group col-xl-2 col-lg-2 col-md-12 mb-0">
                                                    <select
                                                        class="form-control select2-show-search border-bottom-0 w-100"
                                                        data-placeholder="Select">
                                                        <optgroup label="">
                                                            <option>
                                                                Distance
                                                            </option>
                                                            <option value="1">
                                                                3km
                                                            </option>
                                                            <option value="2">
                                                                6km
                                                            </option>
                                                            <option value="3">
                                                                9km
                                                            </option>
                                                            <option value="4">
                                                                10km
                                                            </option>
                                                            <option value="5">
                                                                20km
                                                            </option>
                                                        </optgroup>
                                                    </select>
                                                </div>
                                                <div class="form-group col-xl-2 col-lg-2 col-md-12 mb-0">
                                                    <select
                                                        class="form-control select2-show-search border-bottom-0 w-100"
                                                        data-placeholder="Select">
                                                        <optgroup label="Categories">
                                                            <option>
                                                                Max Fees
                                                            </option>
                                                            <option value="1">
                                                                $10k
                                                            </option>
                                                            <option value="2">
                                                                $10k-$20K
                                                            </option>
                                                            <option value="3">
                                                                $20K-$30K
                                                            </option>
                                                            <option value="4">
                                                                $30K-$40K
                                                            </option>
                                                            <option value="5">
                                                                $40K-$50K
                                                            </option>
                                                            <option value="6">
                                                                $50K-$60K
                                                            </option>
                                                            <option value="7">
                                                                $60K-$70K
                                                            </option>
                                                            <option value="8">
                                                                $70k-$80K
                                                            </option>
                                                            <option value="9">
                                                                $80K &lt; Above
                                                            </option>
                                                        </optgroup>
                                                    </select>
                                                </div>
                                                <div class="form-group col-xl-2 col-lg-2 col-md-12 mb-0">
                                                    <a class="btn btn-block btn-orange fs-14" href="#"><i
                                                            class="fa fa-search"></i> Search</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane" id="tab3">
                                        <div class="search-background">
                                            <div class="form row no-gutters">
                                                <div class="form-group col-xl-4 col-lg-4 col-md-12 mb-0 location">
                                                    <div class="form-group mb-0">
                                                        <input class="form-control border"
                                                            placeholder="Search Location" type="text"> <span><i
                                                                class="fa fa-crosshairs  location-gps mr-1"></i></span>
                                                    </div>
                                                </div>
                                                <div class="form-group col-xl-2 col-lg-2 col-md-12 mb-0">
                                                    <select
                                                        class="form-control select2-show-search border-bottom-0 w-100"
                                                        data-placeholder="Select">
                                                        <optgroup label="Categories">
                                                            <option>
                                                                Fitness Centers
                                                            </option>
                                                            <option value="1">
                                                                Aerobic Centers
                                                            </option>
                                                            <option value="2">
                                                                Yoga Centers
                                                            </option>
                                                            <option value="4">
                                                                Dance Centers
                                                            </option>
                                                            <option value="5">
                                                                Pilates Centers
                                                            </option>
                                                            <option value="5">
                                                                Gyms
                                                            </option>
                                                        </optgroup>
                                                    </select>
                                                </div>
                                                <div class="form-group col-xl-2 col-lg-2 col-md-12 mb-0">
                                                    <select
                                                        class="form-control select2-show-search border-bottom-0 w-100"
                                                        data-placeholder="Select">
                                                        <optgroup label="">
                                                            <option>
                                                                Distance
                                                            </option>
                                                            <option value="1">
                                                                3km
                                                            </option>
                                                            <option value="2">
                                                                6km
                                                            </option>
                                                            <option value="3">
                                                                9km
                                                            </option>
                                                            <option value="4">
                                                                10km
                                                            </option>
                                                            <option value="5">
                                                                20km
                                                            </option>
                                                        </optgroup>
                                                    </select>
                                                </div>
                                                <div class="form-group col-xl-2 col-lg-2 col-md-12 mb-0">
                                                    <select
                                                        class="form-control select2-show-search border-bottom-0 w-100"
                                                        data-placeholder="Select">
                                                        <optgroup label="Categories">
                                                            <option>
                                                                Max Fees
                                                            </option>
                                                            <option value="1">
                                                                $10k
                                                            </option>
                                                            <option value="2">
                                                                $10k-$20K
                                                            </option>
                                                            <option value="3">
                                                                $20K-$30K
                                                            </option>
                                                            <option value="4">
                                                                $30K-$40K
                                                            </option>
                                                            <option value="5">
                                                                $40K-$50K
                                                            </option>
                                                            <option value="6">
                                                                $50K-$60K
                                                            </option>
                                                            <option value="7">
                                                                $60K-$70K
                                                            </option>
                                                            <option value="8">
                                                                $70k-$80K
                                                            </option>
                                                            <option value="9">
                                                                $80K &lt; Above
                                                            </option>
                                                        </optgroup>
                                                    </select>
                                                </div>
                                                <div class="form-group col-xl-2 col-lg-2 col-md-12 mb-0">
                                                    <a class="btn btn-block btn-orange fs-14" href="#"><i
                                                            class="fa fa-search"></i> Search</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane" id="tab4">
                                        <div class="search-background">
                                            <div class="form row no-gutters">
                                                <div class="form-group col-xl-4 col-lg-4 col-md-12 mb-0 location">
                                                    <div class="form-group mb-0">
                                                        <input class="form-control border"
                                                            placeholder="Search Location" type="text"> <span><i
                                                                class="fa fa-crosshairs  location-gps mr-1"></i></span>
                                                    </div>
                                                </div>
                                                <div class="form-group col-xl-2 col-lg-2 col-md-12 mb-0">
                                                    <select
                                                        class="form-control select2-show-search border-bottom-0 w-100"
                                                        data-placeholder="Select">
                                                        <optgroup label="Categories">
                                                            <option>
                                                                Pharmacies
                                                            </option>
                                                            <option value="1">
                                                                Retail pharmacy
                                                            </option>
                                                            <option value="2">
                                                                Hospital pharmacy
                                                            </option>
                                                            <option value="4">
                                                                Clinic pharmacy
                                                            </option>
                                                            <option value="5">
                                                                Home care pharmacy
                                                            </option>
                                                            <option value="5">
                                                                Mail order pharmacy
                                                            </option>
                                                        </optgroup>
                                                    </select>
                                                </div>
                                                <div class="form-group col-xl-2 col-lg-2 col-md-12 mb-0">
                                                    <select
                                                        class="form-control select2-show-search border-bottom-0 w-100"
                                                        data-placeholder="Select">
                                                        <optgroup label="">
                                                            <option>
                                                                Distance
                                                            </option>
                                                            <option value="1">
                                                                3km
                                                            </option>
                                                            <option value="2">
                                                                6km
                                                            </option>
                                                            <option value="3">
                                                                9km
                                                            </option>
                                                            <option value="4">
                                                                10km
                                                            </option>
                                                            <option value="5">
                                                                20km
                                                            </option>
                                                        </optgroup>
                                                    </select>
                                                </div>
                                                <div class="form-group col-xl-2 col-lg-2 col-md-12 mb-0">
                                                    <select
                                                        class="form-control select2-show-search border-bottom-0 w-100"
                                                        data-placeholder="Select">
                                                        <optgroup label="Categories">
                                                            <option>
                                                                Max price
                                                            </option>
                                                            <option value="1">
                                                                $10k
                                                            </option>
                                                            <option value="2">
                                                                $10k-$20K
                                                            </option>
                                                            <option value="3">
                                                                $20K-$30K
                                                            </option>
                                                            <option value="4">
                                                                $30K-$40K
                                                            </option>
                                                            <option value="5">
                                                                $40K-$50K
                                                            </option>
                                                            <option value="6">
                                                                $50K-$60K
                                                            </option>
                                                            <option value="7">
                                                                $60K-$70K
                                                            </option>
                                                            <option value="8">
                                                                $70k-$80K
                                                            </option>
                                                            <option value="9">
                                                                $80K &lt; Above
                                                            </option>
                                                        </optgroup>
                                                    </select>
                                                </div>
                                                <div class="form-group col-xl-2 col-lg-2 col-md-12 mb-0">
                                                    <a class="btn btn-block btn-orange fs-14" href="#"><i
                                                            class="fa fa-search"></i> Search</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane" id="tab5">
                                        <div class="search-background">
                                            <div class="form row no-gutters">
                                                <div class="form-group col-xl-4 col-lg-4 col-md-12 mb-0 location">
                                                    <div class="form-group mb-0">
                                                        <input class="form-control border"
                                                            placeholder="Search Location" type="text"> <span><i
                                                                class="fa fa-crosshairs  location-gps mr-1"></i></span>
                                                    </div>
                                                </div>
                                                <div class="form-group col-xl-2 col-lg-2 col-md-12 mb-0">
                                                    <select
                                                        class="form-control select2-show-search border-bottom-0 w-100"
                                                        data-placeholder="Select">
                                                        <optgroup label="Categories">
                                                            <option>
                                                                Clinics
                                                            </option>
                                                            <option value="1">
                                                                Physiotherapy Clinics
                                                            </option>
                                                            <option value="2">
                                                                Dental Clinics
                                                            </option>
                                                            <option value="4">
                                                                Walk-in Urgent Care Clinics
                                                            </option>
                                                            <option value="5">
                                                                Chiropractor Clinics
                                                            </option>
                                                            <option value="5">
                                                                Rehabilitation Clinics
                                                            </option>
                                                        </optgroup>
                                                    </select>
                                                </div>
                                                <div class="form-group col-xl-2 col-lg-2 col-md-12 mb-0">
                                                    <select
                                                        class="form-control select2-show-search border-bottom-0 w-100"
                                                        data-placeholder="Select">
                                                        <optgroup label="">
                                                            <option>
                                                                Distance
                                                            </option>
                                                            <option value="1">
                                                                3km
                                                            </option>
                                                            <option value="2">
                                                                6km
                                                            </option>
                                                            <option value="3">
                                                                9km
                                                            </option>
                                                            <option value="4">
                                                                10km
                                                            </option>
                                                            <option value="5">
                                                                20km
                                                            </option>
                                                        </optgroup>
                                                    </select>
                                                </div>
                                                <div class="form-group col-xl-2 col-lg-2 col-md-12 mb-0">
                                                    <select
                                                        class="form-control select2-show-search border-bottom-0 w-100"
                                                        data-placeholder="Select">
                                                        <optgroup label="Categories">
                                                            <option>
                                                                Max Fees
                                                            </option>
                                                            <option value="1">
                                                                $10k
                                                            </option>
                                                            <option value="2">
                                                                $10k-$20K
                                                            </option>
                                                            <option value="3">
                                                                $20K-$30K
                                                            </option>
                                                            <option value="4">
                                                                $30K-$40K
                                                            </option>
                                                            <option value="5">
                                                                $40K-$50K
                                                            </option>
                                                            <option value="6">
                                                                $50K-$60K
                                                            </option>
                                                            <option value="7">
                                                                $60K-$70K
                                                            </option>
                                                            <option value="8">
                                                                $70k-$80K
                                                            </option>
                                                            <option value="9">
                                                                $80K &lt; Above
                                                            </option>
                                                        </optgroup>
                                                    </select>
                                                </div>
                                                <div class="form-group col-xl-2 col-lg-2 col-md-12 mb-0">
                                                    <a class="btn btn-block btn-orange fs-14" href="#"><i
                                                            class="fa fa-search"></i> Search</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane" id="tab6">
                                        <div class="search-background">
                                            <div class="form row no-gutters">
                                                <div class="form-group col-xl-4 col-lg-4 col-md-12 mb-0 location">
                                                    <div class="form-group mb-0">
                                                        <input class="form-control border"
                                                            placeholder="Search Location" type="text"> <span><i
                                                                class="fa fa-crosshairs  location-gps mr-1"></i></span>
                                                    </div>
                                                </div>
                                                <div class="form-group col-xl-2 col-lg-2 col-md-12 mb-0">
                                                    <select
                                                        class="form-control select2-show-search border-bottom-0 w-100"
                                                        data-placeholder="Select">
                                                        <optgroup label="Categories">
                                                            <option>
                                                                Blood Banks
                                                            </option>
                                                            <option value="1">
                                                                Central Blood Center
                                                            </option>
                                                            <option value="2">
                                                                San Diego Blood Bank
                                                            </option>
                                                            <option value="4">
                                                                Delta Blood Bank
                                                            </option>
                                                            <option value="5">
                                                                Heartland Blood Centers
                                                            </option>
                                                            <option value="5">
                                                                Florida’s Blood Centers
                                                            </option>
                                                        </optgroup>
                                                    </select>
                                                </div>
                                                <div class="form-group col-xl-2 col-lg-2 col-md-12 mb-0">
                                                    <select
                                                        class="form-control select2-show-search border-bottom-0 w-100"
                                                        data-placeholder="Select">
                                                        <optgroup label="">
                                                            <option>
                                                                Distance
                                                            </option>
                                                            <option value="1">
                                                                3km
                                                            </option>
                                                            <option value="2">
                                                                6km
                                                            </option>
                                                            <option value="3">
                                                                9km
                                                            </option>
                                                            <option value="4">
                                                                10km
                                                            </option>
                                                            <option value="5">
                                                                20km
                                                            </option>
                                                        </optgroup>
                                                    </select>
                                                </div>
                                                <div class="form-group col-xl-2 col-lg-2 col-md-12 mb-0">
                                                    <select
                                                        class="form-control select2-show-search border-bottom-0 w-100"
                                                        data-placeholder="Select">
                                                        <optgroup label="Categories">
                                                            <option>
                                                                Available Bloodgroups
                                                            </option>
                                                            <option value="1">
                                                                A negative
                                                            </option>
                                                            <option value="2">
                                                                A positive
                                                            </option>
                                                            <option value="3">
                                                                B negative
                                                            </option>
                                                            <option value="4">
                                                                B positive
                                                            </option>
                                                            <option value="5">
                                                                AB negative
                                                            </option>
                                                            <option value="6">
                                                                AB positive
                                                            </option>
                                                            <option value="7">
                                                                O negative
                                                            </option>
                                                            <option value="8">
                                                                O positive
                                                            </option>
                                                        </optgroup>
                                                    </select>
                                                </div>
                                                <div class="form-group col-xl-2 col-lg-2 col-md-12 mb-0">
                                                    <a class="btn btn-block btn-orange fs-14" href="#"><i
                                                            class="fa fa-search"></i> Search</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/Section-->

    <!--Section-->
    <section class="sptb">
        <div class="container">
            <div class="section-title center-block text-center">
                <h2>Categories</h2>
                <p>Excepteur sint occaecat cupidatat proident deserunt mollit laborum</p>
            </div>
            <div class="row">
                <div class="col-xl-2 col-sm-6">
                    <div class="card bg-card-light bg-primary-card bg-white">
                        <div class="card-body">
                            <div class="cat-item text-center">
                                <a href="page-list.html"></a>
                                <div class="cat-icon bg-primary-transparent brround text-primary">
                                    <i class="fa fa-hospital-o"></i>
                                </div>
                                <div class="cat-desc">
                                    <h5 class="mb-2">Hospitals</h5>
                                    <p class="badge badge-pill badge-light font-weight-semibold mb-0">45</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-sm-6">
                    <div class="card bg-card-light bg-secondary-card bg-white">
                        <div class="card-body">
                            <div class="cat-item text-center">
                                <a href="page-list.html"></a>
                                <div class="cat-icon bg-secondary-transparent brround text-secondary">
                                    <i class="fa fa-user-md"></i>
                                </div>
                                <div class="cat-desc">
                                    <h5 class="mb-2">Doctors</h5>
                                    <p class="badge badge-pill badge-light font-weight-semibold mb-0">32</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-sm-6">
                    <div class="card bg-card-light bg-info-card bg-white">
                        <div class="card-body">
                            <div class="cat-item text-center">
                                <a href="page-list.html"></a>
                                <div class="cat-icon bg-info-transparent brround text-info">
                                    <i class="fa fa-building-o"></i>
                                </div>
                                <div class="cat-desc">
                                    <h5 class="mb-2">FitnesCenters</h5>
                                    <p class="badge badge-pill badge-light font-weight-semibold mb-0">19</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-sm-6">
                    <div class="card bg-card-light bg-danger-card bg-white">
                        <div class="card-body">
                            <div class="cat-item text-center">
                                <a href="page-list.html"></a>
                                <div class="cat-icon bg-danger-transparent brround text-danger">
                                    <i class="fa fa-medkit"></i>
                                </div>
                                <div class="cat-desc">
                                    <h5 class="mb-2">Pharmacies</h5>
                                    <p class="badge badge-pill badge-light font-weight-semibold mb-0">25</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-sm-6">
                    <div class="card bg-card-light bg-success-card bg-white">
                        <div class="card-body">
                            <div class="cat-item text-center">
                                <a href="page-list.html"></a>
                                <div class="cat-icon bg-success-transparent brround text-success">
                                    <i class="fa fa-stethoscope"></i>
                                </div>
                                <div class="cat-desc">
                                    <h5 class="mb-2">Clinics</h5>
                                    <p class="badge badge-pill  badge-light font-weight-semibold mb-0">23</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-sm-6">
                    <div class="card bg-card-light bg-warning-card bg-white">
                        <div class="card-body">
                            <div class="cat-item text-center">
                                <a href="page-list.html"></a>
                                <div class="cat-icon bg-warning-transparent brround text-warning">
                                    <i class="fa fa-heartbeat"></i>
                                </div>
                                <div class="cat-desc">
                                    <h5 class="mb-2">Bloodbanks</h5>
                                    <p class="badge badge-pill  badge-light font-weight-semibold mb-0">52</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/Section-->

    <!--Section-->
    <section class="sptb section-bg">
        <div class="container">
            <div class="section-title center-block text-center">
                <h2>New Registerd</h2>
                <p>Excepteur sint occaecat cupidatat proident deserunt mollit laborum</p>
            </div>
            <div class="owl-carousel owl-carousel-icons2" id="myCarousel1">
                <div class="item">
                    <div class="card mb-0">
                        <div class="power-ribbon power-ribbon-top-left text-warning">
                            <span class="bg-warning"><i class="fa fa-bolt"></i></span>
                        </div>
                        <div class="item-card2-img">
                            <a href="doctor-details.html"></a>
                            <img alt="img" class="cover-image"
                                src="{{ asset('assets/images/media/0-33.jpg') }}">
                        </div>
                        <div class="item-card2-icons">
                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                    class="fa fa fa-heart-o"></i></a>
                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                    class="fa fa-share-alt"></i></a>
                        </div>
                        <div class="card-body">
                            <div class="item-card2">
                                <small class="text-muted">PHYSIOLOGIST</small>
                                <a class="text-dark" href="doctor-details.html">
                                    <h4 class="font-weight-semibold mt-1 mb-1">Dr.K.Mary..
                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                    </h4>
                                </a>
                                <p class="text-muted fs-13 mb-1">MBBS, MD, DM, Ph.D</p>
                                <div class="rating-stars d-inline-flex mb-1">
                                    <input class="rating-value star" name="rating-stars-value" readonly="readonly"
                                        type="number" value="5">
                                    <div class="rating-stars-container mr-2">
                                        <div class="rating-star sm ">
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <div class="rating-star sm ">
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <div class="rating-star sm ">
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <div class="rating-star sm ">
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <div class="rating-star sm">
                                            <i class="fa fa-star"></i>
                                        </div>
                                    </div>5.0
                                </div>
                                <div class="mb-0 mt-0">
                                    <ul class="item-card-features mb-0">
                                        <li class="mb-0"><span class="text-muted"><i
                                                    class="fa fa-map-marker mr-1"></i> Hyderabad</span></li>
                                        <li><span class="text-muted "><i class="fa fa-briefcase mr-1"></i>3 yrs
                                                Exp</span></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer p-0 btn-appointment">
                            <div class="btn-group w-100">
                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                    href="doctor-details.html"><i class="fe fe-eye mr-1"></i> Visit Website</a>
                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0"
                                    href="#" data-target="#exampleModal" data-toggle="modal"><i
                                        class="fe fe-phone mr-1"></i> Appointment</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="card mb-0">
                        <div class="power-ribbon power-ribbon-top-left text-warning">
                            <span class="bg-warning"><i class="fa fa-bolt"></i></span>
                        </div>
                        <div class="item-card2-img">
                            <a href="fitness-details.html"></a>
                            <img alt="img" class="cover-image"
                                src="{{ asset('assets/images/media/0-30.jpg') }}">
                        </div>
                        <div class="item-card2-icons">
                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                    class="fa fa fa-heart-o"></i></a>
                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                    class="fa fa-share-alt"></i></a>
                        </div>
                        <div class="card-body">
                            <div class="item-card2">
                                <small class="text-muted">FITNESS CENTER</small>
                                <a class="text-dark" href="fitness-details.html">
                                    <h4 class="font-weight-semibold mt-1 mb-1">Fit Race Club..
                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                    </h4>
                                </a>
                                <p class="text-muted fs-13 mb-1"><i class="fa fa-clock-o mr-1"></i>8:00 Am - 11:00 Am
                                </p>
                                <div class="rating-stars d-inline-flex mb-1">
                                    <input class="rating-value star" name="rating-stars-value" readonly="readonly"
                                        type="number" value="3">
                                    <div class="rating-stars-container mr-2">
                                        <div class="rating-star sm ">
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <div class="rating-star sm ">
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <div class="rating-star sm ">
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <div class="rating-star sm ">
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <div class="rating-star sm">
                                            <i class="fa fa-star"></i>
                                        </div>
                                    </div>3.0
                                </div>
                                <div class="mb-0 mt-0">
                                    <ul class="item-card-features mb-0">
                                        <li class="mb-0"><span class="text-muted"><i
                                                    class="fa fa-map-marker mr-1"></i> Hyderabad</span></li>
                                        <li><span class="text-muted "><i class="fa fa fa-calendar-o mr-1"></i> Mon-
                                                Fri</span></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer p-0 btn-appointment">
                            <div class="btn-group w-100">
                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                    href="fitness-details.html"><i class="fe fe-eye mr-1"></i> Visit Website</a>
                                <a
                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                    <div class="call-btn-1">
                                        <i class="fe fe-phone mr-1"></i> Call
                                    </div>
                                    <div class="call-number">
                                        +65 847596 82
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="card mb-0">
                        <div class="item-card2-img">
                            <a href="hospital-details.html"></a>
                            <img alt="img" class="cover-image"
                                src="{{ asset('assets/images/media/0-21.jpg') }}">
                        </div>
                        <div class="item-card2-icons">
                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                    class="fa fa fa-heart text-danger"></i></a>
                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                    class="fa fa-share-alt"></i></a>
                        </div>
                        <div class="card-body">
                            <div class="item-card2">
                                <small class="text-muted">HOSPITAL</small>
                                <a class="text-dark" href="hospital-details.html">
                                    <h4 class="font-weight-semibold mt-1 mb-1">Madlife Hospital..
                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                    </h4>
                                </a>
                                <p class="text-muted fs-13 mb-1"><i class="fa fa-clock-o mr-1"></i>9:00 Am - 7:00 Pm
                                </p>
                                <div class="rating-stars d-inline-flex mb-1">
                                    <input class="rating-value star" name="rating-stars-value" readonly="readonly"
                                        type="number" value="5">
                                    <div class="rating-stars-container mr-2">
                                        <div class="rating-star sm ">
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <div class="rating-star sm ">
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <div class="rating-star sm ">
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <div class="rating-star sm ">
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <div class="rating-star sm">
                                            <i class="fa fa-star"></i>
                                        </div>
                                    </div>5.0
                                </div>
                                <div class="mb-0 mt-0">
                                    <ul class="item-card-features mb-0">
                                        <li class="mb-0"><span class="text-muted"><i
                                                    class="fa fa-map-marker mr-1"></i> Hyderabad</span></li>
                                        <li><span class="text-muted "><i class="fa fa-user-md mr-1"></i>154
                                                Doctors</span></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer p-0 btn-appointment">
                            <div class="btn-group w-100">
                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                    href="hospital-details.html"><i class="fe fe-eye mr-1"></i> Visit Website</a>
                                <a
                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                    <div class="call-btn-1">
                                        <i class="fe fe-phone mr-1"></i> Call
                                    </div>
                                    <div class="call-number">
                                        +65 847596 82
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="card mb-0">
                        <div class="item-card2-img">
                            <a href="pharmacy-details.html"></a>
                            <img alt="img" class="cover-image"
                                src="{{ asset('assets/images/media/0-14.jpg') }}">
                        </div>
                        <div class="item-card2-icons">
                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                    class="fa fa fa-heart-o"></i></a>
                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                    class="fa fa-share-alt"></i></a>
                        </div>
                        <div class="card-body">
                            <div class="item-card2">
                                <small class="text-muted">PHARMACY</small>
                                <a class="text-dark" href="pharmacy-details.html">
                                    <h4 class="font-weight-semibold mt-1 mb-1">Brett Pharma..
                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                    </h4>
                                </a>
                                <p class="text-muted fs-13 mb-1"><i class="fa fa-clock-o mr-1"></i>9:00 Am - 7:00 Pm
                                </p>
                                <div class="rating-stars d-inline-flex mb-1">
                                    <input class="rating-value star" name="rating-stars-value" readonly="readonly"
                                        type="number" value="4">
                                    <div class="rating-stars-container mr-2">
                                        <div class="rating-star sm ">
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <div class="rating-star sm ">
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <div class="rating-star sm ">
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <div class="rating-star sm ">
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <div class="rating-star sm">
                                            <i class="fa fa-star"></i>
                                        </div>
                                    </div>4.3
                                </div>
                                <div class="mb-0 mt-0">
                                    <ul class="item-card-features mb-0">
                                        <li class="mb-0"><span class="text-muted"><i
                                                    class="fa fa-map-marker mr-1"></i> Hyderabad</span></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer p-0 btn-appointment">
                            <div class="btn-group w-100">
                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                    href="pharmacy-details.html"><i class="fe fe-eye mr-1"></i> Visit Website</a>
                                <a
                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                    <div class="call-btn-1">
                                        <i class="fe fe-phone mr-1"></i> Call
                                    </div>
                                    <div class="call-number">
                                        +65 847596 82
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="card mb-0">
                        <div class="power-ribbon power-ribbon-top-left text-warning">
                            <span class="bg-warning"><i class="fa fa-bolt"></i></span>
                        </div>
                        <div class="item-card2-img">
                            <a href="hospital-details.html"></a>
                            <img alt="img" class="cover-image"
                                src="{{ asset('assets/images/media/0-15.jpg') }}">
                        </div>
                        <div class="item-card2-icons">
                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                    class="fa fa fa-heart text-danger"></i></a>
                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                    class="fa fa-share-alt"></i></a>
                        </div>
                        <div class="card-body">
                            <div class="item-card2">
                                <small class="text-muted">CLINIC</small>
                                <a class="text-dark" href="hospital-details.html">
                                    <h4 class="font-weight-semibold mt-1 mb-1">Aesthetic Clinic..
                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                    </h4>
                                </a>
                                <p class="text-muted fs-13 mb-1"><i class="fa fa-clock-o mr-1"></i>9:00 Am - 7:00 Pm
                                </p>
                                <div class="rating-stars d-inline-flex mb-1">
                                    <input class="rating-value star" name="rating-stars-value" readonly="readonly"
                                        type="number" value="4">
                                    <div class="rating-stars-container mb-1 mr-2">
                                        <div class="rating-star sm ">
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <div class="rating-star sm ">
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <div class="rating-star sm ">
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <div class="rating-star sm ">
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <div class="rating-star sm">
                                            <i class="fa fa-star"></i>
                                        </div>
                                    </div>4.0
                                </div>
                                <div class="mb-0 mt-0">
                                    <ul class="item-card-features mb-0">
                                        <li class="mb-0"><span class="text-muted"><i
                                                    class="fa fa-map-marker mr-1"></i> Banglore</span></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer p-0 btn-appointment">
                            <div class="btn-group w-100">
                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                    href="hospital-details.html"><i class="fe fe-eye mr-1"></i> Visit Website</a>
                                <a
                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                    <div class="call-btn-1">
                                        <i class="fe fe-phone mr-1"></i> Call
                                    </div>
                                    <div class="call-number">
                                        +65 847596 82
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="card mb-0">
                        <div class="power-ribbon power-ribbon-top-left text-warning">
                            <span class="bg-warning"><i class="fa fa-bolt"></i></span>
                        </div>
                        <div class="item-card2-img">
                            <a href="bloodbank-details.html"></a>
                            <img alt="img" class="cover-image"
                                src="{{ asset('assets/images/media/0-1.jpg') }}">
                        </div>
                        <div class="item-card2-icons">
                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                    class="fa fa fa-heart text-danger"></i></a>
                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                    class="fa fa-share-alt"></i></a>
                        </div>
                        <div class="card-body">
                            <div class="item-card2">
                                <small class="text-muted">BLOODBANK</small>
                                <a class="text-dark" href="bloodbank-details.html">
                                    <h4 class="font-weight-semibold mt-1 mb-1">City Blood Bank..
                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                    </h4>
                                </a>
                                <p class="text-muted fs-13 mb-1"><i class="fa fa-clock-o mr-1"></i>9:00 Am - 6:00 Pm
                                </p>
                                <div class="rating-stars d-inline-flex mb-1">
                                    <input class="rating-value star" name="rating-stars-value" readonly="readonly"
                                        type="number" value="4">
                                    <div class="rating-stars-container mb-1 mr-2">
                                        <div class="rating-star sm ">
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <div class="rating-star sm ">
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <div class="rating-star sm ">
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <div class="rating-star sm ">
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <div class="rating-star sm">
                                            <i class="fa fa-star"></i>
                                        </div>
                                    </div>4.0
                                </div>
                                <div class="mb-0 mt-0">
                                    <ul class="item-card-features mb-0">
                                        <li class="mb-0"><span class="text-muted"><i
                                                    class="fa fa-map-marker mr-1"></i> Chennai</span></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer p-0 btn-appointment">
                            <div class="btn-group w-100">
                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                    href="bloodbank-details.html"><i class="fe fe-eye mr-1"></i> Visit Website</a>
                                <a
                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                    <div class="call-btn-1">
                                        <i class="fe fe-phone mr-1"></i> Call
                                    </div>
                                    <div class="call-number">
                                        +65 847596 82
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Section-->

    <!--Section-->
    <section class="sptb">
        <div class="container">
            <div class="section-title center-block text-center">
                <h2>Top Rated List</h2>
                <p>Excepteur sint occaecat cupidatat proident deserunt mollit laborum</p>
            </div>
            <div class="items-gallery">
                <div class="items-blog-tab text-center">
                    <div class="items-blog-tab-heading row">
                        <div class="col-12">
                            <ul class="nav items-blog-tab-menu">
                                <li class="">
                                    <a class="active show" data-toggle="tab" href="#tab-1">Doctors</a>
                                </li>
                                <li>
                                    <a class="" data-toggle="tab" href="#tab-2">Hospitals</a>
                                </li>
                                <li>
                                    <a class="" data-toggle="tab" href="#tab-3">FitnesCenters</a>
                                </li>
                                <li>
                                    <a class="" data-toggle="tab" href="#tab-4">Pharmacies</a>
                                </li>
                                <li>
                                    <a class="" data-toggle="tab" href="#tab-5">Clinics</a>
                                </li>
                                <li>
                                    <a class="" data-toggle="tab" href="#tab-6">BloodBanks</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="tab-content list-container">
                        <div class="tab-pane active " id="tab-1">
                            <div class="row">
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs">
                                            <a href="doctor-details.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-33.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">Dermatologist</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart-o"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa-share-alt"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="doctor-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">Dr.S.Ashley..
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1"><i
                                                        class="fa fa-user-md text-muted mr-2"></i>MBBS, MD, DM, Ph.D
                                                </p>
                                                <div class="rating-stars d-inline-flex mb-1">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="3">
                                                    <div class="rating-stars-container mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>3.2
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i>
                                                                Hyderabad</span></li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa-briefcase mr-1"></i>2 yrs Exp</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="doctor-details.html"><i class="fe fe-eye mr-1"></i> Visit
                                                    Website</a>
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0"
                                                    href="#" data-target="#exampleModal"
                                                    data-toggle="modal"><i class="fe fe-phone mr-1"></i>
                                                    Appointment</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs">
                                            <a href="doctor-details.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-34.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">Cardiologist</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart text-danger"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa-share-alt"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="doctor-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">Dr.S.Mary..
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1"><i
                                                        class="fa fa-user-md text-muted mr-2"></i>MBBS, Ph.D</p>
                                                <div class="rating-stars d-inline-flex mb-1">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="3">
                                                    <div class="rating-stars-container mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>3.0
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i> Chennai</span>
                                                        </li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa-briefcase mr-1"></i>3 yrs Exp</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="doctor-details.html"><i class="fe fe-eye mr-1"></i> Visit
                                                    Website</a>
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0"
                                                    href="#" data-target="#exampleModal"
                                                    data-toggle="modal"><i class="fe fe-phone mr-1"></i>
                                                    Appointment</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs">
                                            <a href="doctor-details.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-35.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">Neurologist</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart-o"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa-share-alt"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="doctor-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">Dr.M.Julia..
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1"><i
                                                        class="fa fa-user-md text-muted mr-2"></i>MBBS, MD, DM,
                                                    FAMS,Ph.D</p>
                                                <div class="rating-stars d-inline-flex mb-1">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="3">
                                                    <div class="rating-stars-container mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>3.2
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i> Banglore</span>
                                                        </li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa-briefcase mr-1"></i>4 yrs Exp</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="doctor-details.html"><i class="fe fe-eye mr-1"></i> Visit
                                                    Website</a>
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0"
                                                    href="#" data-target="#exampleModal"
                                                    data-toggle="modal"><i class="fe fe-phone mr-1"></i>
                                                    Appointment</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs"><a href="doctor-details.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-36.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">Gynecologist</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart text-danger"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa-share-alt"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="doctor-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">Dr.M.Angela..
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1"><i
                                                        class="fa fa-user-md text-muted mr-2"></i>MBBS, MD, DM, Ph.D
                                                </p>
                                                <div class="rating-stars d-inline-flex mb-1">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="4">
                                                    <div class="rating-stars-container mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>4.5
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i> Chennai</span>
                                                        </li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa-briefcase mr-1"></i>5 yrs Exp</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="doctor-details.html"><i class="fe fe-eye mr-1"></i> Visit
                                                    Website</a>
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0"
                                                    href="#" data-target="#exampleModal"
                                                    data-toggle="modal"><i class="fe fe-phone mr-1"></i>
                                                    Appointment</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs">
                                            <a href="doctor-details.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-37.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">Orthopedic surgeon</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart-o"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa-share-alt"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="doctor-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">Dr.B.Diana..
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1"><i
                                                        class="fa fa-user-md text-muted mr-2"></i>MBBS, MD, DM, FAMS
                                                </p>
                                                <div class="rating-stars d-inline-flex mb-1">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="3">
                                                    <div class="rating-stars-container mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>3.2
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i>
                                                                Hyderabad</span></li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa-briefcase mr-1"></i>2 yrs Exp</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="doctor-details.html"><i class="fe fe-eye mr-1"></i> Visit
                                                    Website</a>
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0"
                                                    href="#" data-target="#exampleModal"
                                                    data-toggle="modal"><i class="fe fe-phone mr-1"></i>
                                                    Appointment</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" id="tab-2">
                            <div class="row">
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs">
                                            <a href="hospital-details.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-23.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">Hospital</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart text-danger"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa-share-alt"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="hospital-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">Safewest Hospital..
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1">359 N. Edgefield Dr. West Roxbury, MA
                                                    02132....</p>
                                                <div class="rating-stars d-inline-flex mb-1">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="5">
                                                    <div class="rating-stars-container mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>5.0
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i>Hyderabad</span>
                                                        </li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa-user-md mr-1"></i>154 Doctors</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="hospital-details.html"><i class="fe fe-eye mr-1"></i>
                                                    Visit Website</a>
                                                <a
                                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                                    <div class="call-btn-1">
                                                        <i class="fe fe-phone mr-1"></i> Call
                                                    </div>
                                                    <div class="call-number">
                                                        +65 847596 82
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs">
                                            <a href="hospital-details.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-23.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">Hospital</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart-o"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa-share-alt"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="hospital-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">Angelwalk Hospital..
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1">273 Tailwater St.Wadsworth, OH
                                                    442812....</p>
                                                <div class="rating-stars d-inline-flex mb-1">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="3">
                                                    <div class="rating-stars-container mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>3.7
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i>Chennai</span>
                                                        </li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa-user-md mr-1"></i>50 Doctors</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="hospital-details.html"><i class="fe fe-eye mr-1"></i>
                                                    Visit Website</a>
                                                <a
                                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                                    <div class="call-btn-1">
                                                        <i class="fe fe-phone mr-1"></i> Call
                                                    </div>
                                                    <div class="call-number">
                                                        +65 847596 82
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs">
                                            <a href="hospital-details.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-21.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">Hospital</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart-o"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa-share-alt"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="hospital-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">West valley hospital..
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1">359 N. Edgefield Dr. West Roxbury, MA
                                                    02132.</p>
                                                <div class="rating-stars d-inline-flex mb-1">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="4">
                                                    <div class="rating-stars-container mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>4.0
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i> Banglore</span>
                                                        </li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa-user-md mr-1"></i>60 Doctors</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="hospital-details.html"><i class="fe fe-eye mr-1"></i>
                                                    Visit Website</a>
                                                <a
                                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                                    <div class="call-btn-1">
                                                        <i class="fe fe-phone mr-1"></i> Call
                                                    </div>
                                                    <div class="call-number">
                                                        +65 847596 82
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs">
                                            <a href="hospital-details.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-25.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">Hospital</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart text-danger"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa-share-alt"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="hospital-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">Hope Hospital..
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1">5 Temple Lane. Glendora, CA
                                                    91740.....</p>
                                                <div class="rating-stars d-inline-flex mb-1">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="5">
                                                    <div class="rating-stars-container mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>5.0
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i> Kolkata</span>
                                                        </li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa-user-md mr-1"></i>150 Doctors</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="hospital-details.html"><i class="fe fe-eye mr-1"></i>
                                                    Visit Website</a>
                                                <a
                                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                                    <div class="call-btn-1">
                                                        <i class="fe fe-phone mr-1"></i> Call
                                                    </div>
                                                    <div class="call-number">
                                                        +65 847596 82
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs">
                                            <a href="hospital-details.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-12.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">Hospital</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart-o"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa-share-alt"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="hospital-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">Highland Hospital..
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1">935 Ridgewood St. Piscataway, NJ
                                                    08854.....</p>
                                                <div class="rating-stars d-inline-flex mb-1">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="4">
                                                    <div class="rating-stars-container mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>4.3
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i>
                                                                Hyderabad</span></li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa-user-md mr-1"></i>60 Doctors</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="hospital-details.html"><i class="fe fe-eye mr-1"></i>
                                                    Visit Website</a>
                                                <a
                                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                                    <div class="call-btn-1">
                                                        <i class="fe fe-phone mr-1"></i> Call
                                                    </div>
                                                    <div class="call-number">
                                                        +65 847596 82
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" id="tab-3">
                            <div class="row">
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs">
                                            <a href="fitness-details.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-26.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">Fitness Center</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-l bg-dark-transparent"
                                                href="classified.html"><i class="fa fa-share-alt"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart-o"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="fitness-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">Fit Race Club..
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1">273 Tailwater St. Wadsworth, OH
                                                    44281.</p>
                                                <div class="rating-stars d-inline-flex mb-1">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="3">
                                                    <div class="rating-stars-container mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>3.0
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i>
                                                                Hyderabad</span></li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa fa-calendar-o mr-1"></i>Mon-Fri</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="hospital-details.html"><i class="fe fe-eye mr-1"></i>
                                                    Visit Website</a>
                                                <a
                                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                                    <div class="call-btn-1">
                                                        <i class="fe fe-phone mr-1"></i> Call
                                                    </div>
                                                    <div class="call-number">
                                                        +65 847596 82
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs">
                                            <a href="fitness-details.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-27.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">Fitness Center</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-l bg-dark-transparent" href="#"><i
                                                    class="fa fa-share-alt"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart text-danger"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="fitness-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">Fitness Essentials..
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1">359 N. Edgefield Dr. West Roxbury, MA
                                                    02132..</p>
                                                <div class="rating-stars d-inline-flex mb-1">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="4">
                                                    <div class="rating-stars-container mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>4.3
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i> Chennai</span>
                                                        </li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa fa-calendar-o mr-1"></i>Mon-Fri</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="hospital-details.html"><i class="fe fe-eye mr-1"></i>
                                                    Visit Website</a>
                                                <a
                                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                                    <div class="call-btn-1">
                                                        <i class="fe fe-phone mr-1"></i> Call
                                                    </div>
                                                    <div class="call-number">
                                                        +65 847596 82
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs">
                                            <a href="fitness-details.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-28.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">Fitness Center</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-l bg-dark-transparent" href="#"><i
                                                    class="fa fa-share-alt"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart text-danger"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="fitness-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">Curl Fitness..
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1">273 Tailwater St. Wadsworth, OH
                                                    44281.</p>
                                                <div class="rating-stars d-inline-flex mb-1">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="3">
                                                    <div class="rating-stars-container mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>3.3
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i>
                                                                Hyderabad</span></li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa fa-calendar-o mr-1"></i>Mon-Fri</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="hospital-details.html"><i class="fe fe-eye mr-1"></i>
                                                    Visit Website</a>
                                                <a
                                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                                    <div class="call-btn-1">
                                                        <i class="fe fe-phone mr-1"></i> Call
                                                    </div>
                                                    <div class="call-number">
                                                        +65 847596 82
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs">
                                            <a href="fitness-details.html.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-10.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">Fitness Center</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-l bg-dark-transparent" href="#"><i
                                                    class="fa fa-share-alt"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart-o"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="fitness-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">C3 Fitness..
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1">935 Ridgewood St. Piscataway, NJ
                                                    08854..</p>
                                                <div class="rating-stars d-inline-flex mb-1">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="5">
                                                    <div class="rating-stars-container mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>5.0
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i>
                                                                Hyderabad</span></li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa fa-calendar-o mr-1"></i>Mon-Fri</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="hospital-details.html"><i class="fe fe-eye mr-1"></i>
                                                    Visit Website</a>
                                                <a
                                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                                    <div class="call-btn-1">
                                                        <i class="fe fe-phone mr-1"></i> Call
                                                    </div>
                                                    <div class="call-number">
                                                        +65 847596 82
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs">
                                            <a href="fitness-details.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-29.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">Fitness Center</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-l bg-dark-transparent" href="#"><i
                                                    class="fa fa-share-alt"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart-o"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="fitness-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">Corenetic Gym..
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1">359 N. Edgefield Dr. West Roxbury, MA
                                                    02132.</p>
                                                <div class="rating-stars d-inline-flex mb-1">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="4">
                                                    <div class="rating-stars-container mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>4.8
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i> Banglore</span>
                                                        </li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa fa-calendar-o mr-1"></i>Mon-Fri</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="hospital-details.html"><i class="fe fe-eye mr-1"></i>
                                                    Visit Website</a>
                                                <a
                                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                                    <div class="call-btn-1">
                                                        <i class="fe fe-phone mr-1"></i> Call
                                                    </div>
                                                    <div class="call-number">
                                                        +65 847596 82
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs">
                                            <a href="fitness-details.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-30.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">Fitness Center</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-l bg-dark-transparent" href="#"><i
                                                    class="fa fa-share-alt"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart text-danger"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="fitness-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">Eco Fitness..
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1">935 Ridgewood St. Piscataway, NJ
                                                    08854...</p>
                                                <div class="rating-stars d-inline-flex mb-1">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="4">
                                                    <div class="rating-stars-container mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>4.3
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i>
                                                                Hyderabad</span></li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa fa-calendar-o mr-1"></i>Mon-Fri</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="hospital-details.html"><i class="fe fe-eye mr-1"></i>
                                                    Visit Website</a>
                                                <a
                                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                                    <div class="call-btn-1">
                                                        <i class="fe fe-phone mr-1"></i> Call
                                                    </div>
                                                    <div class="call-number">
                                                        +65 847596 82
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs">
                                            <a href="fitness-details.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-31.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">Fitness Center</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-l bg-dark-transparent" href="#"><i
                                                    class="fa fa-share-alt"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart-o"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="fitness-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">Fitness Bot..
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1">359 N. Edgefield Dr. West Roxbury, MA
                                                    02132..</p>
                                                <div class="rating-stars d-inline-flex mb-1">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="3">
                                                    <div class="rating-stars-container mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>3.0
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i>
                                                                Hyderabad</span></li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa fa-calendar-o mr-1"></i>Mon-Fri</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="hospital-details.html"><i class="fe fe-eye mr-1"></i>
                                                    Visit Website</a>
                                                <a
                                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                                    <div class="call-btn-1">
                                                        <i class="fe fe-phone mr-1"></i> Call
                                                    </div>
                                                    <div class="call-number">
                                                        +65 847596 82
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs">
                                            <a href="fitness-details.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-32.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">Fitness Center</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-l bg-dark-transparent" href="#"><i
                                                    class="fa fa-share-alt"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart-o"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="fitness-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">CrossFit Solcity...
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1">985 Fremont St. Saint Cloud, MN
                                                    56301..</p>
                                                <div class="rating-stars d-inline-flex mb-1">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="4">
                                                    <div class="rating-stars-container mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>4.5
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i>
                                                                Hyderabad</span></li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa fa-calendar-o mr-1"></i>Mon-Fri</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="hospital-details.html"><i class="fe fe-eye mr-1"></i>
                                                    Visit Website</a>
                                                <a
                                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                                    <div class="call-btn-1">
                                                        <i class="fe fe-phone mr-1"></i> Call
                                                    </div>
                                                    <div class="call-number">
                                                        +65 847596 82
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" id="tab-4">
                            <div class="row">
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs">
                                            <a href="pharmacy-details.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-14.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">Pharmacy</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart text-danger"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa-share-alt"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="pharmacy-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">Craft Pharmacy..
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1">714 Bowman Street. North Miami Beach,
                                                    FL 33160....</p>
                                                <div class="rating-stars d-inline-flex mb-1">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="4">
                                                    <div class="rating-stars-container mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>4.7
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i> Chennai</span>
                                                        </li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa-clock-o mr-1"></i>8 Am - 4 Pm</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="hospital-details.html"><i class="fe fe-eye mr-1"></i>
                                                    Visit Website</a>
                                                <a
                                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                                    <div class="call-btn-1">
                                                        <i class="fe fe-phone mr-1"></i> Call
                                                    </div>
                                                    <div class="call-number">
                                                        +65 847596 82
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs">
                                            <a href="pharmacy-details.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-17.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">Pharmacy</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart-o"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa-share-alt"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="pharmacy-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">Vista Pharmacy..
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1">82 Clinton Street. Sun Prairie, WI
                                                    53590....</p>
                                                <div class="rating-stars d-inline-flex mb-1">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="4">
                                                    <div class="rating-stars-container mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>4.7
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i> Banglore</span>
                                                        </li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa-clock-o mr-1"></i>10 Am - 7 Pm</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="hospital-details.html"><i class="fe fe-eye mr-1"></i>
                                                    Visit Website</a>
                                                <a
                                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                                    <div class="call-btn-1">
                                                        <i class="fe fe-phone mr-1"></i> Call
                                                    </div>
                                                    <div class="call-number">
                                                        +65 847596 82
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs">
                                            <a href="pharmacy-details.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-18.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">Pharmacy</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart text-danger"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa-share-alt"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="pharmacy-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">Pharma Street..
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1">323 Fifth Ave. Canandaigua, NY
                                                    14424....</p>
                                                <div class="rating-stars d-inline-flex mb-1">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="3">
                                                    <div class="rating-stars-container mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>3.0
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i>
                                                                Hyderabad</span></li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa-clock-o mr-1"></i>9 Am - 6 Pm</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="hospital-details.html"><i class="fe fe-eye mr-1"></i>
                                                    Visit Website</a>
                                                <a
                                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                                    <div class="call-btn-1">
                                                        <i class="fe fe-phone mr-1"></i> Call
                                                    </div>
                                                    <div class="call-number">
                                                        +65 847596 82
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs">
                                            <a href="pharmacy-details.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-19.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">Pharmacy</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart-o"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa-share-alt"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="pharmacy-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">IHC Pharmacy..
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1">935 Ridgewood St. Piscataway, NJ
                                                    08854.....</p>
                                                <div class="rating-stars d-inline-flex mb-1">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="4">
                                                    <div class="rating-stars-container  mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>4.0
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i> Chennai</span>
                                                        </li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa-clock-o mr-1"></i>11 Am - 6 Pm</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="hospital-details.html"><i class="fe fe-eye mr-1"></i>
                                                    Visit Website</a>
                                                <a
                                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                                    <div class="call-btn-1">
                                                        <i class="fe fe-phone mr-1"></i> Call
                                                    </div>
                                                    <div class="call-number">
                                                        +65 847596 82
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs">
                                            <a href="pharmacy-details.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-20.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">Pharmacy</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart text-danger"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa-share-alt"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="pharmacy-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">Madico Pharmacy..
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1">82 Clinton Street. Sun Prairie, WI
                                                    53590....</p>
                                                <div class="rating-stars d-inline-flex mb-1">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="4">
                                                    <div class="rating-stars-container mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>4.7
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i> Banglore</span>
                                                        </li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa-clock-o mr-1"></i>10 Am - 7 Pm</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="hospital-details.html"><i class="fe fe-eye mr-1"></i>
                                                    Visit Website</a>
                                                <a
                                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                                    <div class="call-btn-1">
                                                        <i class="fe fe-phone mr-1"></i> Call
                                                    </div>
                                                    <div class="call-number">
                                                        +65 847596 82
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" id="tab-5">
                            <div class="row">
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs">
                                            <a href="hospital-details.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-5.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">Clinic</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart-o"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa-share-alt"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="hospital-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">Grace Clinic..
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1">935 Ridgewood St. Piscataway, NJ
                                                    08854.....</p>
                                                <div class="rating-stars d-inline-flex mb-1">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="4">
                                                    <div class="rating-stars-container mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>4.0
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i> Chennai</span>
                                                        </li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa-clock-o mr-1"></i>11 Am - 6 Pm</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="hospital-details.html"><i class="fe fe-eye mr-1"></i>
                                                    Visit Website</a>
                                                <a
                                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                                    <div class="call-btn-1">
                                                        <i class="fe fe-phone mr-1"></i> Call
                                                    </div>
                                                    <div class="call-number">
                                                        +65 847596 82
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs">
                                            <a href="hospital-details.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-6.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">Clinic</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart text-danger"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa-share-alt"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="hospital-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">Stonefield clinic..
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1">323 Fifth Ave. Canandaigua, NY
                                                    14424....</p>
                                                <div class="rating-stars d-inline-flex mb-1">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="3">
                                                    <div class="rating-stars-container mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>3.0
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i>
                                                                Hyderabad</span></li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa-clock-o mr-1"></i>9 Am - 6 Pm</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="hospital-details.html"><i class="fe fe-eye mr-1"></i>
                                                    Visit Website</a>
                                                <a
                                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                                    <div class="call-btn-1">
                                                        <i class="fe fe-phone mr-1"></i> Call
                                                    </div>
                                                    <div class="call-number">
                                                        +65 847596 82
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs">
                                            <a href="hospital-details.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-7.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">Clinic</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart-o"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa-share-alt"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="hospital-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">Happy space’s Clinic..
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1">82 Clinton Street. Sun Prairie, WI
                                                    53590....</p>
                                                <div class="rating-stars d-inline-flex mb-1">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="4">
                                                    <div class="rating-stars-container mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>4.7
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i> Banglore</span>
                                                        </li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa-clock-o mr-1"></i>10 Am - 7 Pm</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="hospital-details.html"><i class="fe fe-eye mr-1"></i>
                                                    Visit Website</a>
                                                <a
                                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                                    <div class="call-btn-1">
                                                        <i class="fe fe-phone mr-1"></i> Call
                                                    </div>
                                                    <div class="call-number">
                                                        +65 847596 82
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs">
                                            <a href="hospital-details.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-15.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">Clinic</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart text-danger"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa-share-alt"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="hospital-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">LifeShades Clinic..
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1">714 Bowman Street. North Miami Beach,
                                                    FL 33160....</p>
                                                <div class="rating-stars d-inline-flex mb-1">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="4">
                                                    <div class="rating-stars-container mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>4.7
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i> Chennai</span>
                                                        </li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa-clock-o mr-1"></i>8 Am - 4 Pm</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="hospital-details.html"><i class="fe fe-eye mr-1"></i>
                                                    Visit Website</a>
                                                <a
                                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                                    <div class="call-btn-1">
                                                        <i class="fe fe-phone mr-1"></i> Call
                                                    </div>
                                                    <div class="call-number">
                                                        +65 847596 82
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs">
                                            <a href="hospital-details.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-8.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">Clinic</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart-o"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa-share-alt"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="hospital-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">WishyWave Clinic..
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1">82 Clinton Street. Sun Prairie, WI
                                                    53590.....</p>
                                                <div class="rating-stars d-inline-flex mb-1">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="5">
                                                    <div class="rating-stars-container  mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>5.0
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i>
                                                                Hyderabad</span></li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa-clock-o mr-1"></i>9 Am - 5 Pm</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="hospital-details.html"><i class="fe fe-eye mr-1"></i>
                                                    Visit Website</a>
                                                <a
                                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                                    <div class="call-btn-1">
                                                        <i class="fe fe-phone mr-1"></i> Call
                                                    </div>
                                                    <div class="call-number">
                                                        +65 847596 82
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" id="tab-6">
                            <div class="row">
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs">
                                            <a href="bloodbank-details.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-16.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">BloodBank</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart text-danger"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa-share-alt"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="bloodbank-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">Delta Blood Bank..
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1">82 Clinton Street. Sun Prairie, WI
                                                    53590.....</p>
                                                <div class="rating-stars d-inline-flex mb-1 mr-3">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="5">
                                                    <div class="rating-stars-container mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>5.0
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i>
                                                                Hyderabad</span></li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa-clock-o mr-1"></i>9 Am - 5 Pm</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="hospital-details.html"><i class="fe fe-eye mr-1"></i>
                                                    Visit Website</a>
                                                <a
                                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                                    <div class="call-btn-1">
                                                        <i class="fe fe-phone mr-1"></i> Call
                                                    </div>
                                                    <div class="call-number">
                                                        +65 847596 82
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs">
                                            <a href="bloodbank-details.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-1.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">BloodBank</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart-o"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa-share-alt"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="bloodbank-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">BloodSource..
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1">323 Fifth Ave. Canandaigua, NY
                                                    14424......</p>
                                                <div class="rating-stars d-inline-flex mb-1 mr-3">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="4">
                                                    <div class="rating-stars-container mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>4.7
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i> Chennai</span>
                                                        </li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa-clock-o mr-1"></i>11 Am - 6 Pm</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="hospital-details.html"><i class="fe fe-eye mr-1"></i>
                                                    Visit Website</a>
                                                <a
                                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                                    <div class="call-btn-1">
                                                        <i class="fe fe-phone mr-1"></i> Call
                                                    </div>
                                                    <div class="call-number">
                                                        +65 847596 82
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs">
                                            <a href="bloodbank-details.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-2.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">BloodBank</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart text-danger"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa-share-alt"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="bloodbank-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">Florida Blood Center..
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1">82 Clinton Street. Sun Prairie, WI
                                                    53590....</p>
                                                <div class="rating-stars d-inline-flex mb-1">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="4">
                                                    <div class="rating-stars-container mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>4.7
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i>
                                                                Hyderabad</span></li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa-clock-o mr-1"></i>9 Am - 4 Pm</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="hospital-details.html"><i class="fe fe-eye mr-1"></i>
                                                    Visit Website</a>
                                                <a
                                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                                    <div class="call-btn-1">
                                                        <i class="fe fe-phone mr-1"></i> Call
                                                    </div>
                                                    <div class="call-number">
                                                        +65 847596 82
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs">
                                            <a href="bloodbank-details.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-3.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">BloodBank</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart-o"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa-share-alt"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="bloodbank-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">Central Blood Bank...
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1">714 Bowman Street. North Miami Beach,
                                                    FL 33160.....</p>
                                                <div class="rating-stars d-inline-flex mb-1">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="4">
                                                    <div class="rating-stars-container mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>4.7
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i> Chennai</span>
                                                        </li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa-clock-o mr-1"></i>10 Am - 5 Pm</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="hospital-details.html"><i class="fe fe-eye mr-1"></i>
                                                    Visit Website</a>
                                                <a
                                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                                    <div class="call-btn-1">
                                                        <i class="fe fe-phone mr-1"></i> Call
                                                    </div>
                                                    <div class="call-number">
                                                        +65 847596 82
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-xl-3">
                                    <div class="card">
                                        <div class="item-card7-imgs">
                                            <a href="bloodbank-details.html"></a>
                                            <img alt="img" class="cover-image"
                                                src="{{ asset('assets/images/media/0-4.jpg') }}">
                                            <div class="tag-text">
                                                <span class="bg-dark tag-option">BloodBank</span>
                                            </div>
                                        </div>
                                        <div class="item-card2-icons">
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa fa-heart text-danger"></i></a>
                                            <a class="item-card2-icons-r bg-dark-transparent" href="#"><i
                                                    class="fa fa-share-alt"></i></a>
                                        </div>
                                        <div class="card-body">
                                            <div class="item-card2">
                                                <a class="text-dark" href="bloodbank-details.html">
                                                    <h4 class="font-weight-semibold mt-1 mb-1">Regional Blood Bank...
                                                        <i class="ion-checkmark-circled  text-success fs-14 ml-1"></i>
                                                    </h4>
                                                </a>
                                                <p class="text-muted fs-13 mb-1">323 Fifth Ave. Canandaigua, NY
                                                    14424...</p>
                                                <div class="rating-stars d-inline-flex mb-1">
                                                    <input class="rating-value star" name="rating-stars-value"
                                                        readonly="readonly" type="number" value="4">
                                                    <div class="rating-stars-container mr-2">
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm ">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                        <div class="rating-star sm">
                                                            <i class="fa fa-star"></i>
                                                        </div>
                                                    </div>4.0
                                                </div>
                                                <div class="mb-0 mt-0">
                                                    <ul class="item-card-features mb-0">
                                                        <li class="mb-0"><span class="text-muted"><i
                                                                    class="fa fa-map-marker mr-1"></i>
                                                                Hyderabad</span></li>
                                                        <li><span class="text-muted "><i
                                                                    class="fa fa-clock-o mr-1"></i>10 Am - 5 Pm</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-footer p-0 btn-appointment">
                                            <div class="btn-group w-100">
                                                <a class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-left-0 border-right-0"
                                                    href="hospital-details.html"><i class="fe fe-eye mr-1"></i>
                                                    Visit Website</a>
                                                <a
                                                    class="w-50 btn btn-outline-light p-2 border-top-0 border-bottom-0 border-right-0 call-btn">
                                                    <div class="call-btn-1">
                                                        <i class="fe fe-phone mr-1"></i> Call
                                                    </div>
                                                    <div class="call-number">
                                                        +65 847596 82
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/Section-->

    <!--Statistics-->
    <section>
        <div class="about-1 cover-image sptb bg-background-color"
            data-image-src="{{ asset('assets/images/banners/banner4.jpg') }}">
            <div class="content-text mb-0 text-white info">
                <div class="container">
                    <div class="row text-center">
                        <div class="col-lg-3 col-md-6">
                            <div class="counter-status md-mb-0">
                                <div class="counter-icon">
                                    <i class="icon icon-trophy"></i>
                                </div>
                                <h5 class="font-weight-normal">Total Awards</h5>
                                <h2 class="counter mb-0">569</h2>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="counter-status status-1 md-mb-0">
                                <div class="counter-icon text-warning">
                                    <i class="icon icon-people"></i>
                                </div>
                                <h5 class="font-weight-normal">Total Experts</h5>
                                <h2 class="counter mb-0">1765</h2>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="counter-status status md-mb-0">
                                <div class="counter-icon text-primary">
                                    <i class="icon icon-globe"></i>
                                </div>
                                <h5 class="font-weight-normal">Total Countries</h5>
                                <h2 class="counter mb-0">1846</h2>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="counter-status status">
                                <div class="counter-icon text-success">
                                    <i class="icon icon-emotsmile"></i>
                                </div>
                                <h5 class="font-weight-normal">Happy Customers</h5>
                                <h2 class="counter mb-0">7253</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/Statistics-->

    <!--Section-->
    <section class="sptb">
        <div class="container">
            <div class="section-title center-block text-center">
                <h2>Latest Articles</h2>
                <p>Excepteur sint occaecat cupidatat proident deserunt mollit laborum</p>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-12 col-xl-4">
                    <div class="card">
                        <div class="item7-card-img">
                            <a href="articles.html"></a>
                            <img src="{{ asset('assets/images/media/photos/1.jpg') }}" alt="img"
                                class="cover-image">
                        </div>
                        <div class="card-body p-4">
                            <a href="articles.html" class="text-dark">
                                <h4>Spminal Papers in Spinal Surgery</h4>
                            </a>
                            <p class="fs-13 text-muted">Dr.S.Ashley. Orthopedic surgeon</p>
                            <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium
                                voluptatum </p>
                            <div class="d-flex">
                                <a href="#" data-toggle="tooltip" data-placement="top" title="likes"><i
                                        class="fe fe-heart text-muted mr-2"></i>0</a>
                                <div class="ml-auto">
                                    <a href="#" data-toggle="tooltip" data-placement="top"
                                        title="share"><i class="fe fe-share-2 text-muted mr-2"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-12 col-xl-4">
                    <div class="card">
                        <div class="item7-card-img">
                            <a href="articles.html"></a>
                            <img src="{{ asset('assets/images/media/photos/2.jpg') }}" alt="img"
                                class="cover-image">
                        </div>
                        <div class="card-body p-4">
                            <a href="articles.html" class="text-dark">
                                <h4>Exercise Fit for a good health</h4>
                            </a>
                            <p class="fs-13 text-muted">Gym Trainer</p>
                            <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium
                                voluptatum </p>
                            <div class="d-flex">
                                <a href="#" data-toggle="tooltip" data-placement="top" title="likes"><i
                                        class="fe fe-heart text-muted mr-2"></i>8</a>
                                <div class="ml-auto">
                                    <a href="#" data-toggle="tooltip" data-placement="top"
                                        title="share"><i class="fe fe-share-2 text-muted mr-2"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-12 col-xl-4">
                    <div class="card">
                        <div class="item7-card-img">
                            <a href="articles.html"></a>
                            <img src="{{ asset('assets/images/media/photos/3.jpg') }}" alt="img"
                                class="cover-image">
                        </div>
                        <div class="card-body p-4">
                            <a href="articles.html" class="text-dark">
                                <h4>Skin Crae and Repair , Healthy Skin</h4>
                            </a>
                            <p class="fs-13 text-muted">Dr.Dr.M.Angela. Dermatologist</p>
                            <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium
                                voluptatum </p>
                            <div class="d-flex">
                                <a href="#" data-toggle="tooltip" data-placement="top" title="likes"><i
                                        class="fe fe-heart text-muted mr-2"></i>5</a>
                                <div class="ml-auto">
                                    <a href="#" data-toggle="tooltip" data-placement="top"
                                        title="share"><i class="fe fe-share-2 text-muted mr-2"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/Section-->

    <!--Section-->
    <section class="sptb position-relative pattern">
        <div class="container">
            <div class="section-title center-block text-center">
                <h2 class="text-white position-relative">Testimonials</h2>
                <p class="text-white position-relative">Excepteur sint occaecat cupidatat proident deserunt mollit
                    laborum</p>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="owl-carousel testimonial-owl-carousel" id="myCarousel">
                        <div class="item text-center">
                            <div class="row">
                                <div class="col-xl-8 col-md-12 d-block mx-auto">
                                    <div class="testimonia">
                                        <div class="owl-controls clickable">
                                            <div class="owl-pagination">
                                                <div class="owl-page active">
                                                    <span class=""></span>
                                                </div>
                                                <div class="owl-page">
                                                    <span class=""></span>
                                                </div>
                                                <div class="owl-page">
                                                    <span class=""></span>
                                                </div>
                                            </div>
                                        </div>
                                        <h3 class="title">Elizabeth</h3>
                                        <div class="rating-stars mb-3">
                                            <input class="rating-value star" name="rating-stars-value"
                                                readonly="readonly" type="number" value="4">
                                            <div class="rating-stars-container">
                                                <div class="rating-star sm ">
                                                    <i class="fa fa-star"></i>
                                                </div>
                                                <div class="rating-star sm ">
                                                    <i class="fa fa-star"></i>
                                                </div>
                                                <div class="rating-star sm ">
                                                    <i class="fa fa-star"></i>
                                                </div>
                                                <div class="rating-star sm">
                                                    <i class="fa fa-star"></i>
                                                </div>
                                                <div class="rating-star sm">
                                                    <i class="fa fa-star"></i>
                                                </div>
                                            </div>
                                        </div>
                                        <p class="text-white-80"><i class="fa fa-quote-left text-white-80"></i>
                                            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quod eos id
                                            officiis hic tenetur quae quaerat ad velit ab. Lorem ipsum dolor sit amet,
                                            consectetur adipisicing elit. Dolore cum accusamus eveniet molestias
                                            voluptatum inventore laboriosam labore sit, aspernatur praesentium iste
                                            impedit quidem dolor veniam.</p>
                                        <a href="testimonial.html" class="btn btn-secondary btn-lg">View all
                                            Testimonials</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item text-center">
                            <div class="row">
                                <div class="col-xl-8 col-md-12 d-block mx-auto">
                                    <div class="testimonia">
                                        <div class="testimonia-data">
                                            <div class="owl-controls clickable">
                                                <div class="owl-pagination">
                                                    <div class="owl-page">
                                                        <span class=""></span>
                                                    </div>
                                                    <div class="owl-page active">
                                                        <span class=""></span>
                                                    </div>
                                                    <div class="owl-page">
                                                        <span class=""></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <h3 class="title">williamson</h3>
                                            <div class="rating-stars mb-3">
                                                <input class="rating-value star" name="rating-stars-value"
                                                    readonly="readonly" type="number" value="3">
                                                <div class="rating-stars-container">
                                                    <div class="rating-star sm">
                                                        <i class="fa fa-star"></i>
                                                    </div>
                                                    <div class="rating-star sm">
                                                        <i class="fa fa-star"></i>
                                                    </div>
                                                    <div class="rating-star sm">
                                                        <i class="fa fa-star"></i>
                                                    </div>
                                                    <div class="rating-star sm">
                                                        <i class="fa fa-star"></i>
                                                    </div>
                                                    <div class="rating-star sm">
                                                        <i class="fa fa-star"></i>
                                                    </div>
                                                </div>
                                            </div>
                                            <p class="text-white-80"><i class="fa fa-quote-left"></i> Duis aute
                                                irure reprehenderit quia voluptas sit aspernatur aut odit aut fugit, sed
                                                quia consequuntur magni dolores eos qui ratione voluptatem sequi
                                                nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit
                                                amet, consectetur, adipisci velit, sed quia non numquam eius modi
                                                tempora incidunt ut labore.</p>
                                        </div>
                                        <a href="testimonial.html" class="btn btn-secondary btn-lg">View all
                                            Testimonials</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item text-center">
                            <div class="row">
                                <div class="col-xl-8 col-md-12 d-block mx-auto">
                                    <div class="testimonia">
                                        <div class="owl-controls clickable">
                                            <div class="owl-pagination">
                                                <div class="owl-page">
                                                    <span class=""></span>
                                                </div>
                                                <div class="owl-page">
                                                    <span class=""></span>
                                                </div>
                                                <div class="owl-page active">
                                                    <span class=""></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="testimonia-data">
                                            <h3 class="title">Sophie Carr</h3>
                                            <div class="rating-stars mb-3">
                                                <input class="rating-value star" name="rating-stars-value"
                                                    readonly="readonly" type="number" value="3">
                                                <div class="rating-stars-container">
                                                    <div class="rating-star sm">
                                                        <i class="fa fa-star"></i>
                                                    </div>
                                                    <div class="rating-star sm">
                                                        <i class="fa fa-star"></i>
                                                    </div>
                                                    <div class="rating-star sm">
                                                        <i class="fa fa-star"></i>
                                                    </div>
                                                    <div class="rating-star sm">
                                                        <i class="fa fa-star"></i>
                                                    </div>
                                                    <div class="rating-star sm">
                                                        <i class="fa fa-star"></i>
                                                    </div>
                                                </div>
                                            </div>
                                            <p class="text-white-80"><i class="fa fa-quote-left"></i> Duis aute
                                                irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
                                                fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
                                                sunt in culpa qui officia deserunt mollit anim id est laborum. usantium
                                                doloremque laudantium.</p>
                                        </div>
                                        <a href="testimonial.html" class="btn btn-secondary btn-lg">View all
                                            Testimonials</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/Section-->

    <!--Section-->
    <section class="sptb">
        <div class="container">
            <div class="section-title center-block text-center">
                <h2>Our Clinets</h2>
                <p>Excepteur sint occaecat cupidatat proident deserunt mollit laborum</p>
            </div>
            <div id="small-categories" class="owl-carousel client-carousel">
                <div class="item">
                    <div class="client-img">
                        <img src="{{ asset('assets/images/clients/1.png') }}" alt="img">
                    </div>
                </div>
                <div class="item">
                    <div class="client-img">
                        <img src="{{ asset('assets/images/clients/2.png') }}" alt="img">
                    </div>
                </div>
                <div class="item">
                    <div class="client-img">
                        <img src="{{ asset('assets/images/clients/3.png') }}" alt="img">
                    </div>
                </div>
                <div class="item">
                    <div class="client-img">
                        <img src="{{ asset('assets/images/clients/4.png') }}" alt="img">
                    </div>
                </div>
                <div class="item">
                    <div class="client-img">
                        <img src="{{ asset('assets/images/clients/5.png') }}" alt="img">
                    </div>
                </div>
                <div class="item">
                    <div class="client-img">
                        <img src="{{ asset('assets/images/clients/6.png') }}" alt="img">
                    </div>
                </div>
                <div class="item">
                    <div class="client-img">
                        <img src="{{ asset('assets/images/clients/7.png') }}" alt="img">
                    </div>
                </div>
                <div class="item">
                    <div class="client-img">
                        <img src="{{ asset('assets/images/clients/8.png') }}" alt="img">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/Section-->

    <!--Section-->
    <section class="sptb section-bg">
        <div class="container">
            <div class="section-title center-block text-center">
                <h2>Best Rated Locations</h2>
                <p>Excepteur sint occaecat cupidatat proident deserunt mollit laborum</p>
            </div>
            <div class="row">
                <div class="col-12 col-md-12 col-lg-12 col-xl-6">
                    <div class="row">
                        <div class="col-sm-12 col-lg-6 col-md-6 ">
                            <div class="item-card overflow-hidden">
                                <div class="item-card-desc">
                                    <a href="#"></a>
                                    <div class="card overflow-hidden border-0">
                                        <div class="card-img">
                                            <img src="{{ asset('assets/images/media/locations/3.jpg') }}"
                                                alt="img" class="cover-image">
                                        </div>
                                        <div class="item-tags">
                                            <div class="bg-secondary tag-option"><i
                                                    class="fa fa fa-heart-o mr-1"></i> 689 </div>
                                        </div>
                                        <div class="item-card-text">
                                            <h4 class="">44,327<span class="item-subtext"><i
                                                        class="fa fa-map-marker mr-1 text-secondary"></i>GERMANY</span>
                                            </h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12 col-lg-6 col-md-6 ">
                            <div class="item-card overflow-hidden">
                                <div class="item-card-desc">
                                    <a href="#"></a>
                                    <div class="card overflow-hidden border-0">
                                        <div class="card-img">
                                            <img src="{{ asset('assets/images/media/locations/6.jpg') }}"
                                                alt="img" class="cover-image">
                                        </div>
                                        <div class="item-tags">
                                            <div class="bg-secondary tag-option"><i
                                                    class="fa fa fa-heart-o mr-1"></i> 491 </div>
                                        </div>
                                        <div class="item-card-text">
                                            <h4 class="">52,145<span class="item-subtext"><i
                                                        class="fa fa-map-marker mr-1 text-secondary"></i>
                                                    LONDON</span></h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12 col-lg-6 col-md-6 ">
                            <div class="item-card overflow-hidden">
                                <div class="item-card-desc">
                                    <a href="#"></a>
                                    <div class="card overflow-hidden border-0">
                                        <div class="card-img">
                                            <img src="{{ asset('assets/images/media/locations/1.jpg') }}"
                                                alt="img" class="cover-image">
                                        </div>
                                        <div class="item-tags">
                                            <div class="bg-secondary tag-option"><i
                                                    class="fa fa fa-heart-o mr-1"></i> 729 </div>
                                        </div>
                                        <div class="item-card-text">
                                            <h4 class="">63,263<span class="item-subtext"><i
                                                        class="fa fa-map-marker text-secondary mr-1"></i>AUSTERLIA</span>
                                            </h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12 col-lg-6 col-md-6 ">
                            <div class="item-card overflow-hidden">
                                <div class="item-card-desc">
                                    <a href="#"></a>
                                    <div class="card overflow-hidden border-0">
                                        <div class="card-img">
                                            <img src="{{ asset('assets/images/media/locations/2.jpg') }}"
                                                alt="img" class="cover-image">
                                        </div>
                                        <div class="item-tags">
                                            <div class="bg-secondary tag-option"><i
                                                    class="fa fa fa-heart-o mr-1"></i> 567 </div>
                                        </div>
                                        <div class="item-card-text">
                                            <h4 class="">36,485<span class="item-subtext"><i
                                                        class="fa fa-map-marker text-secondary mr-1"></i>CHICAGO</span>
                                            </h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-12 col-lg-12 col-xl-6">
                    <div class="row">
                        <div class="col-lg-6 col-xl-6 col-md-6">
                            <div class="item-card overflow-hidden">
                                <div class="item-card-desc">
                                    <a href="#"></a>
                                    <div class="card overflow-hidden border-0">
                                        <div class="card-img">
                                            <img src="{{ asset('assets/images/media/locations/8.jpg') }}"
                                                alt="img" class="cover-image">
                                        </div>
                                        <div class="item-tags">
                                            <div class="bg-secondary tag-option"><i
                                                    class="fa fa fa-heart-o mr-1"></i> 209 </div>
                                        </div>
                                        <div class="item-card-text">
                                            <h4 class="">64,825<span class="item-subtext"><i
                                                        class="fa fa-map-marker text-secondary mr-1"></i>WASHINGTON</span>
                                            </h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-6 col-xl-6">
                            <div class="item-card overflow-hidden">
                                <div class="item-card-desc">
                                    <a href="#"></a>
                                    <div class="card overflow-hidden border-0">
                                        <div class="card-img">
                                            <img src="{{ asset('assets/images/media/locations/5.jpg') }}"
                                                alt="img" class="cover-image">
                                        </div>
                                        <div class="item-tags">
                                            <div class="bg-secondary tag-option"><i
                                                    class="fa fa fa-heart-o mr-1"></i> 567 </div>
                                        </div>
                                        <div class="item-card-text">
                                            <h4 class="">73,5345<span class="item-subtext"><i
                                                        class="fa fa-map-marker text-secondary mr-1"></i>JAPAN</span>
                                            </h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 col-xl-12">
                            <div class="item-card overflow-hidden">
                                <div class="item-card-desc">
                                    <a href="#"></a>
                                    <div class="card overflow-hidden border-0">
                                        <div class="card-img">
                                            <img src="{{ asset('assets/images/media/locations/7.jpg') }}"
                                                alt="img" class="cover-image">
                                        </div>
                                        <div class="item-tags">
                                            <div class="bg-secondary tag-option"><i
                                                    class="fa fa fa-heart-o mr-1"></i> 567 </div>
                                        </div>
                                        <div class="item-card-text">
                                            <h4 class="">64,825<span class="item-subtext"><i
                                                        class="fa fa-map-marker text-secondary mr-1"></i>CANADA</span>
                                            </h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Section-->

    <!--Section-->
    <section class="sptb">
        <div class="container">
            <div class="section-title center-block text-center">
                <h2>News & Latest Posts</h2>
                <p>Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua</p>
            </div>
            <div id="defaultCarousel" class="owl-carousel Card-owlcarousel owl-carousel-icons">
                <div class="item">
                    <div class="card mb-0">
                        <div class="item7-card-img">
                            <a href="#"></a>
                            <img src="{{ asset('assets/images/media/photos/11.jpg') }}" alt="img"
                                class="cover-image">
                        </div>
                        <div class="card-body p-4">
                            <div class="item7-card-desc d-flex mb-2">
                                <a href="#"><i class="fa fa-calendar-o text-muted mr-2"></i>Dec-03-2019</a>
                                <div class="ml-auto">
                                    <a href="#"><i class="fa fa-comment-o text-muted mr-2"></i>4 Comments</a>
                                </div>
                            </div>
                            <a href="blog-details.html" class="text-dark">
                                <h4>Duis aute irure reprehenderit</h4>
                            </a>
                            <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium
                                voluptatum </p>
                            <div class="d-flex align-items-center pt-2 mt-auto">
                                <img src="{{ asset('assets/images/users/male/5.jpg') }}"
                                    class="avatar brround avatar-md mr-3" alt="avatar-img">
                                <div>
                                    <a href="profile.html" class="text-default">Joanne Nash</a>
                                    <small class="d-block text-muted">1 day ago</small>
                                </div>
                                <div class="ml-auto text-muted">
                                    <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i
                                            class="fe fe-heart mr-1"></i></a>
                                    <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i
                                            class="fa fa-thumbs-o-up"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="card mb-0">
                        <div class="item7-card-img">
                            <a href="#"></a>
                            <img src="{{ asset('assets/images/media/photos/12.jpg') }}" alt="img"
                                class="cover-image">
                        </div>
                        <div class="card-body p-4">
                            <div class="item7-card-desc d-flex mb-2">
                                <a href="#"><i class="fa fa-calendar-o text-muted mr-2"></i>Nov-28-2019</a>
                                <div class="ml-auto">
                                    <a href="#"><i class="fa fa-comment-o text-muted mr-2"></i>2 Comments</a>
                                </div>
                            </div>
                            <a href="blog-details.html" class="text-dark">
                                <h4>Nam libero tempore soluta</h4>
                            </a>
                            <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium
                                voluptatum </p>
                            <div class="d-flex align-items-center pt-2 mt-auto">
                                <img src="{{ asset('assets/images/users/male/7.jpg') }}"
                                    class="avatar brround avatar-md mr-3" alt="avatar-img">
                                <div>
                                    <a href="profile.html" class="text-default">Tanner Mallari</a>
                                    <small class="d-block text-muted">2 days ago</small>
                                </div>
                                <div class="ml-auto text-muted">
                                    <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i
                                            class="fe fe-heart mr-1"></i></a>
                                    <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i
                                            class="fa fa-thumbs-o-up"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="card mb-0">
                        <div class="item7-card-img">
                            <a href="#"></a>
                            <img src="{{ asset('assets/images/media/photos/13.jpg') }}" alt="img"
                                class="cover-image">
                        </div>
                        <div class="card-body p-4">
                            <div class="item7-card-desc d-flex mb-2">
                                <a href="#"><i class="fa fa-calendar-o text-muted mr-2"></i>Nov-19-2019</a>
                                <div class="ml-auto">
                                    <a href="#"><i class="fa fa-comment-o text-muted mr-2"></i>8 Comments</a>
                                </div>
                            </div>
                            <a href="blog-details.html" class="text-dark">
                                <h4>At vero eos et accusamus et iusto</h4>
                            </a>
                            <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium
                                voluptatum </p>
                            <div class="d-flex align-items-center pt-2 mt-auto">
                                <img src="{{ asset('assets/images/users/female/15.jpg') }}"
                                    class="avatar brround avatar-md mr-3" alt="avatar-img">
                                <div>
                                    <a href="profile.html" class="text-default">Aracely Bashore</a>
                                    <small class="d-block text-muted">5 days ago</small>
                                </div>
                                <div class="ml-auto text-muted">
                                    <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i
                                            class="fe fe-heart mr-1"></i></a>
                                    <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i
                                            class="fa fa-thumbs-o-up"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="card mb-0">
                        <div class="item7-card-img">
                            <a href="#"></a>
                            <img src="{{ asset('assets/images/media/photos/14.jpg') }}" alt="img"
                                class="cover-image">
                        </div>
                        <div class="card-body p-4">
                            <div class="item7-card-desc d-flex mb-2">
                                <a href="#"><i class="fa fa-calendar-o text-muted mr-2"></i>Dec-03-2019</a>
                                <div class="ml-auto">
                                    <a href="#"><i class="fa fa-comment-o text-muted mr-2"></i>4 Comments</a>
                                </div>
                            </div>
                            <a href="blog-details.html" class="text-dark">
                                <h4 class="font-weight-semibold">Et harum quidem rerum facilis est</h4>
                            </a>
                            <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium
                                voluptatum </p>
                            <div class="d-flex align-items-center pt-2 mt-auto">
                                <img src="{{ asset('assets/images/users/male/15.jpg') }}"
                                    class="avatar brround avatar-md mr-3" alt="avatar-img">
                                <div>
                                    <a href="profile.html" class="text-default">Royal Hamblin</a>
                                    <small class="d-block text-muted">10 days ago</small>
                                </div>
                                <div class="ml-auto text-muted">
                                    <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i
                                            class="fe fe-heart mr-1"></i></a>
                                    <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i
                                            class="fa fa-thumbs-o-up"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="card mb-0">
                        <div class="item7-card-img">
                            <a href="#"></a>
                            <img src="{{ asset('assets/images/media/photos/15.jpg') }}" alt="img"
                                class="cover-image">
                        </div>
                        <div class="card-body p-4">
                            <div class="item7-card-desc d-flex mb-2">
                                <a href="#"><i class="fa fa-calendar-o text-muted mr-2"></i>Nov-28-2019</a>
                                <div class="ml-auto">
                                    <a href="#"><i class="fa fa-comment-o text-muted mr-2"></i>2 Comments</a>
                                </div>
                            </div>
                            <a href="blog-details.html" class="text-dark">
                                <h4 class="font-weight-semibold">Sed ut perspiciatis unde omnis iste</h4>
                            </a>
                            <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium
                                voluptatum </p>
                            <div class="d-flex align-items-center pt-2 mt-auto">
                                <img src="{{ asset('assets/images/users/female/5.jpg') }}"
                                    class="avatar brround avatar-md mr-3" alt="avatar-img">
                                <div>
                                    <a href="profile.html" class="text-default">Rosita Chatmon</a>
                                    <small class="d-block text-muted">10 days ago</small>
                                </div>
                                <div class="ml-auto text-muted">
                                    <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i
                                            class="fe fe-heart mr-1"></i></a>
                                    <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i
                                            class="fa fa-thumbs-o-up"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="card mb-0">
                        <div class="item7-card-img">
                            <a href="#"></a>
                            <img src="{{ asset('assets/images/media/photos/16.jpg') }}" alt="img"
                                class="cover-image">
                        </div>
                        <div class="card-body p-4">
                            <div class="item7-card-desc d-flex mb-2">
                                <a href="#"><i class="fa fa-calendar-o text-muted mr-2"></i>Nov-19-2019</a>
                                <div class="ml-auto">
                                    <a href="#"><i class="fa fa-comment-o text-muted mr-2"></i>8 Comments</a>
                                </div>
                            </div>
                            <a href="blog-details.html" class="text-dark">
                                <h4 class="font-weight-semibold">At vero eos et accusamus et iusto</h4>
                            </a>
                            <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium
                                voluptatum </p>
                            <div class="d-flex align-items-center pt-2 mt-auto">
                                <img src="{{ asset('assets/images/users/male/6.jpg') }}"
                                    class="avatar brround avatar-md mr-3" alt="avatar-img">
                                <div>
                                    <a href="profile.html" class="text-default">Loyd Nolf</a>
                                    <small class="d-block text-muted">15 days ago</small>
                                </div>
                                <div class="ml-auto text-muted">
                                    <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i
                                            class="fe fe-heart mr-1"></i></a>
                                    <a href="javascript:void(0)" class="icon d-none d-md-inline-block ml-3"><i
                                            class="fa fa-thumbs-o-up"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/Section-->

    <!--Section-->
    <section class="sptb section-bg">
        <div class="container">
            <div class="section-title center-block text-center">
                <h2>Download Apps</h2>
                <p>Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua</p>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="text-center text-wrap">
                        <div class="btn-list">
                            <a href="#" class="btn btn-primary btn-lg mb-sm-0"><i
                                    class="fa fa-apple fa-1x mr-2"></i> App Store</a>
                            <a href="#" class="btn btn-secondary btn-lg mb-sm-0"><i
                                    class="fa fa-android fa-1x mr-2"></i> Google Play</a>
                            <a href="#" class="btn btn-info btn-lg mb-0"><i
                                    class="fa fa-windows fa-1x mr-2"></i> Windows</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/Section-->

    <!--Footer Section-->
    <section>
        <footer class="text-white footer-bg">
            <div class="footer-main">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-2 col-md-12">
                            <h6>About</h6>
                            <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto mt-0">
                            <ul class="list-unstyled mb-0">
                                <li>
                                    <a href="javascript:;">Our Team</a>
                                </li>
                                <li>
                                    <a href="javascript:;">Contact US</a>
                                </li>
                                <li>
                                    <a href="javascript:;">Faq</a>
                                </li>
                                <li>
                                    <a href="javascript:;">Careers</a>
                                </li>
                                <li>
                                    <a href="javascript:;">Blog</a>
                                </li>
                            </ul>
                        </div>
                        <div class="col-lg-2 col-md-12">
                            <h6>Resources</h6>
                            <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto mt-0">
                            <ul class="list-unstyled mb-0">
                                <li>
                                    <a href="javascript:;">Search Doctor</a>
                                </li>
                                <li>
                                    <a href="javascript:;">Search Hospital</a>
                                </li>
                                <li>
                                    <a href="javascript:;">Search Clinic</a>
                                </li>
                                <li>
                                    <a href="javascript:;">Search Fitnesscenter</a>
                                </li>
                                <li>
                                    <a href="javascript:;">Search BloodBank</a>
                                </li>
                            </ul>
                        </div>
                        <div class="col-lg-2 col-md-12">
                            <h6>More</h6>
                            <hr class="deep-purple text-primary accent-2 mb-4 mt-0 d-inline-block mx-auto">
                            <div class="clearfix"></div>
                            <ul class="list-unstyled mb-0">
                                <li>
                                    <a href="javascript:;">Help</a>
                                </li>
                                <li>
                                    <a href="javascript:;">Terms and Services</a>
                                </li>
                                <li>
                                    <a href="javascript:;">Book Appointments</a>
                                </li>
                                <li>
                                    <a href="javascript:;">Privacy Policy</a>
                                </li>
                                <li>
                                    <a href="javascript:;">Subscribers</a>
                                </li>
                            </ul>
                        </div>
                        <div class="col-lg-3 col-md-12">
                            <h6>Contact</h6>
                            <hr class="deep-purple text-primary accent-2 mb-4 mt-0 d-inline-block mx-auto">
                            <ul class="list-unstyled mb-0 contact-footer">
                                <li>
                                    <i class="fa fa-map-marker"></i> 22 S. Rock Creek StreetSan Carlos, Uniontown CA
                                    94070, USA
                                </li>
                                <li>
                                    <i class="fa fa-envelope "></i>info12323@example.com
                                </li>
                                <li>
                                    <i class="fa fa-phone"></i>+ 01 234 567 88
                                </li>
                                <li>
                                    <i class="fa fa-print"></i>+ 01 234 567 89
                                </li>
                            </ul>
                        </div>
                        <div class="col-lg-3 col-md-12">
                            <h6>Subscribe</h6>
                            <hr class="deep-purple text-primary accent-2 mb-4 mt-0 d-inline-block mx-auto">
                            <div class="clearfix"></div>
                            <div class="input-group w-100">
                                <input class="form-control br-tl-3 br-bl-3" placeholder="Email" type="text">
                                <div class="input-group-append">
                                    <button class="btn btn-primary br-tr-3 br-br-3"
                                        type="button">Subscribe</button>
                                </div>
                            </div>
                            <h6 class="mt-5">Follow Us</h6>
                            <hr class="deep-purple text-primary accent-2 mb-4 mt-0 d-inline-block mx-auto">
                            <ul class="list-unstyled list-inline follow-footer">
                                <li class="list-inline-item">
                                    <a class="btn-floating btn-sm"><i class="fa fa-facebook"></i></a>
                                </li>
                                <li class="list-inline-item">
                                    <a class="btn-floating btn-sm"><i class="fa fa-twitter"></i></a>
                                </li>
                                <li class="list-inline-item">
                                    <a class="btn-floating btn-sm"><i class="fa fa-google-plus"></i></a>
                                </li>
                                <li class="list-inline-item">
                                    <a class="btn-floating btn-sm"><i class="fa fa-linkedin"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="text-white p-0">
                <div class="container">
                    <div class="row d-flex">
                        <div class="col-lg-12 col-sm-12 mt-3 mb-3 text-center">
                            Copyright © 2019 <a class="fs-14 text-white-50" href="#">Medz</a>. Designed by <a
                                class="fs-14 text-white-50" href="https://www.spruko.com/"> Spruko Technologies
                                Pvt.Ltd </a> All rights reserved.
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </section>
    <!--Footer Section-->

    <!-- Popup Login-->
    <div class="modal" id="exampleModal">
        <div class="modal-dialog modal-lg modal-appoint" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Make an Appointment</h5><button
                        aria-label="Close" class="close" data-dismiss="modal" type="button"><span
                            aria-hidden="true">×</span></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Your Name</label>
                                <input class="form-control" placeholder="Enter Your Name" type="text">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Your Email</label>
                                <input class="form-control" placeholder="Enter your Email" type="email">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Your Number</label>
                                <input class="form-control" placeholder="Enter your Phone Number" type="number">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Select Gender</label>
                                <select class="form-control select2" name="user[hour]">
                                    <option value="">Male</option>
                                    <option value="0">Female</option>
                                    <option value="1">Others</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="form-label">Select Date</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text">
                                            <i class="fa fa-calendar tx-16 lh-0 op-6"></i>
                                        </div>
                                    </div><input class="form-control fc-datepicker" placeholder="MM/DD/YYYY"
                                        type="text">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Select City</label>
                                <select class="form-control custom-select select2-show-search" name="city">
                                    <option selected value="0">Select City</option>
                                    <option value="1">Hyderabad</option>
                                    <option value="2">Mumbai</option>
                                    <option value="3">Delhi</option>
                                    <option value="4">Bangalore</option>
                                    <option value="5">Ahmedabad</option>
                                    <option value="6">Chennai</option>
                                    <option value="7">Kolkata</option>
                                    <option value="8">Lucknow</option>
                                    <option value="9">Jaipur</option>
                                    <option value="10">Bhopal</option>
                                    <option value="11">Visakhapatnam</option>
                                    <option value="12">Patna</option>
                                    <option value="13">Srinagar</option>
                                    <option value="14">Lucknow</option>
                                    <option value="15">Bhubaneswar</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Select Hospital</label>
                                <select class="form-control custom-select select2-show-search" name="Hospital">
                                    <option selected value="0">Select Hospital</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Select Specialist</label>
                                <select class="form-control custom-select select2-show-search" name="Specialist">
                                    <option selected value="0">Select Specialist</option>
                                    <option value="1">Cardiologist</option>
                                    <option value="2">Neurosurgeon</option>
                                    <option value="3">Orthopaedic Surgeon</option>
                                    <option value="4">Oncologist</option>
                                    <option value="5">Neurologist</option>
                                    <option value="6">Gastroenterologist</option>
                                    <option value="7">ENT</option>
                                    <option value="8">Dentist</option>
                                    <option value="9">Psychiatrist</option>
                                    <option value="10">Urologist</option>
                                    <option value="11">Gynecologist</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">Select Slot</label>
                                <select class="form-control custom-select select2-show-search" name="Slot">
                                    <option selected value="0">Select Hospital</option>
                                    <option value="1">Moring</option>
                                    <option value="2">Afternoon</option>
                                    <option value="3">Evening</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="">
                        <a class="btn btn-orange btn-block" href="#">Book Appointment</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Popup Login-->

    <!-- Back to top -->
    <a href="#top" id="back-to-top"><i class="fa fa-angle-double-up"></i></a>

    <!-- JQuery js-->
    <script src="{{ asset('assets/js/jquery-3.2.1.min.js') }}"></script>

    <!-- Bootstrap js -->
    <script src="{{ asset('assets/plugins/bootstrap/js/popper.min.js') }}"></script>
    <script src="{{ asset('assets/plugins/bootstrap/js/bootstrap.min.js') }}"></script>

    <!--JQueryVehiclerkline Js-->
    <script src="{{ asset('assets/js/jquery.sparkline.min.js') }}"></script>

    <!-- Circle Progress Js-->
    <script src="{{ asset('assets/js/circle-progress.min.js') }}"></script>

    <!-- Star Rating Js-->
    <script src="{{ asset('assets/plugins/rating/jquery.rating-stars.js') }}"></script>

    <!--Counters -->
    <script src="{{ asset('assets/plugins/counters/counterup.min.js') }}"></script>
    <script src="{{ asset('assets/plugins/counters/waypoints.min.js') }}"></script>
    <script src="{{ asset('assets/plugins/counters/numeric-counter.js') }}"></script>

    <!--Owl Carousel js -->
    <script src="{{ asset('assets/plugins/owl-carousel/owl.carousel.js') }}"></script>

    <!--Horizontal Menu-->
    <script src="{{ asset('assets/plugins/horizontal/horizontal.js') }}"></script>

    <!--JQuery TouchSwipe js-->
    <script src="{{ asset('assets/js/jquery.touchSwipe.min.js') }}"></script>

    <!--Select2 js -->
    <script src="{{ asset('assets/plugins/select2/select2.full.min.js') }}"></script>
    <script src="{{ asset('assets/js/select2.js') }}"></script>

    <!-- Datepicker js -->
    <script src="{{ asset('assets/plugins/date-picker/spectrum.js') }}"></script>
    <script src="{{ asset('assets/plugins/date-picker/jquery-ui.js') }}"></script>
    <script src="{{ asset('assets/plugins/date-picker/datepicker.js') }}"></script>

    <!-- sticky Js-->
    <script src="{{ asset('assets/js/sticky.js') }}"></script>

    <!-- Cookie js -->
    <script src="{{ asset('assets/plugins/cookie/jquery.ihavecookies.js') }}"></script>
    <script src="{{ asset('assets/plugins/cookie/cookie.js') }}"></script>

    <!-- Custom scroll bar Js-->
    <script src="{{ asset('assets/plugins/scroll-bar/jquery.mCustomScrollbar.concat.min.js') }}"></script>

    <!--Showmore Js-->
    <script src="{{ asset('assets/js/jquery.showmore.js') }}"></script>
    <script src="{{ asset('assets/js/showmore.js') }}"></script>

    <!-- Swipe Js-->
    <script src="{{ asset('assets/js/swipe.js') }}"></script>

    <!--Owl-Carousel Js-->
    <script src="{{ asset('assets/js/owl-carousel.js') }}"></script>

    <!-- Custom Js-->
    <script src="{{ asset('assets/js/custom.js') }}"></script>
</body>

</html>
