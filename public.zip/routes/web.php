<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\ServiceController;
use App\Http\Controllers\SpecialityController;
use App\Http\Controllers\UserController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// user root
Route::group(['prefix' => 'admin'], function () {
    Auth::routes();
    Route::group(['middleware' => ['auth']], function () {
        Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
        Route::resource('category', CategoryController::class);
        Route::resource('service', ServiceController::class);
        Route::resource('speciality',SpecialityController::class);
        Route::get('speciality/listing',[SpecialityController::class,'listing'])->name('speciality.listing');
        Route::resource('user',UserController::class);
        Route::get('user/listing',[UserController::class,'listing'])->name('user.listing');

    });
});
// user root
Route::group(['prefix' => 'user'], function () {
    // Route::get('login')
});

// public root
Route::group(['middleware' => ['auth']], function () {
    Route::get('/logout', [HomeController::class, 'perform'])->name('logout.perform');
});
Route::get('get-states',[HomeController::class,'get_state'])->name('get.state');
Route::get('get-city',[HomeController::class,'get_city'])->name('get.city');
