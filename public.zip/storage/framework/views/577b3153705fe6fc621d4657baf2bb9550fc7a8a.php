<!doctype html>
<html lang="en" dir="ltr">

<head>
    <meta charset="UTF-8">
    <meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=0'>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Medz - Medical Directory HTML Template">
    <meta name="author" content="Spruko Technologies Private Limited">
    <meta name="keywords"
        content="appointments, booking, bootstrap list template,  directory listing html template,  directory website template, doctor directory, doctor search, health template, healthcare directory, hospital,  html css templates, html directory listing, listing, medical bootstrap template, medical directory, medical html template , medical template,  medical web templates, medical website templates, pharma website templates, responsive html template,template html css, online directory website,  html5 template, themeforest html,  online directory, simple html templates ">

    <!-- Favicon -->
    <link rel="icon" href="<?php echo e(asset('assets/images/brand/favicon.ico')); ?>" type="image/x-icon" />
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets/images/brand/favicon.ico')); ?>" />

    <!-- Title -->
    <title>Dashboard</title>


    <!-- Sidemenu Css -->
    <link href="<?php echo e(asset('assets/css/sidemenu.css')); ?>" rel="stylesheet" />


    <!-- Bootstrap Css -->
    <link href="<?php echo e(asset('assets/plugins/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" />

    <!-- Style Css -->
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/admin-custom.css')); ?>" rel="stylesheet" />

    <!-- p-scroll bar css-->
    <link href="<?php echo e(asset('assets/plugins/pscrollbar/pscrollbar.css')); ?>" rel="stylesheet" />

    <!---Font icons-->
    <link href="<?php echo e(asset('assets/css/icons.css')); ?>" rel="stylesheet" />

    <!--Color-Skin Css -->
    <link href="<?php echo e(asset('assets/color-skins/color10.css')); ?>" id="theme" media="all" rel="stylesheet">

    <link href="<?php echo e(asset('assets/plugins/sweet-alert/sweetalert.css')); ?>" rel="stylesheet" />

    <?php echo $__env->yieldContent('head'); ?>
    <style>
        select.form-control:not([size]):not([multiple]) {
            height: 29px;
            margin: 0px 5px;
        }
        .dataTables_length label{
            display: inline-flex;
        }
        .dataTables_length input,select{
            height: 35px;
        }
    </style>
</head>

<body class="app sidebar-mini">
    <script type="text/javascript">
        var base_url = '<?php echo e(url("/")); ?>';
  </script>

    <!--Loader-->
    <div id="global-loader">
        <img alt="" class="loader-img" src="<?php echo e(asset('assets/images/loader.svg')); ?>">
    </div>
    <!--/Loader-->

    <div class="page">
        <div class="page-main h-100">
            <?php echo $__env->make('admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Sidebar menu-->
            <?php echo $__env->make('admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <!--footer-->
        <?php echo $__env->make('admin.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- End Footer-->
    </div>
    <!-- Back to top -->
    <a href="#top" id="back-to-top"><i class="fa fa-rocket"></i></a>


    <!-- Dashboard Core -->
    <script src="<?php echo e(asset('assets/js/jquery-3.2.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/bootstrap/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.sparkline.min.js')); ?>"></script>
    <script src=""></script>
    <script src="<?php echo e(asset('assets/js/jquery.tablesorter.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/circle-progress.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/rating/jquery.rating-stars.js')); ?>"></script>

    <!-- Fullside-menu Js-->
    <script src="<?php echo e(asset('assets/plugins/sidemenu/sidemenu.js')); ?>"></script>


    <!-- ECharts Plugin -->
    

    <!-- Input Mask Plugin -->
    <script src="<?php echo e(asset('assets/plugins/input-mask/jquery.mask.min.js')); ?>"></script>

    <!--Counters -->
    <script src="<?php echo e(asset('assets/plugins/counters/counterup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/counters/waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/counters/numeric-counter.js')); ?>"></script>

    <!-- p-scroll bar Js-->
    <script src="<?php echo e(asset('assets/plugins/pscrollbar/pscrollbar.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/pscrollbar/pscroll.js')); ?>"></script>

    <!-- Index Scripts -->
    <script src="<?php echo e(asset('assets/js/index4.js')); ?>"></script>



    <!-- Custom Js-->
    <script src="<?php echo e(asset('assets/js/admin-custom.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/sweet-alert/sweetalert.min.js')); ?>"></script>
    <?php if(Session::has('success')): ?>
        <script>
            $(document).ready(function() {
                swal('Success', '<?php echo e(Session::get('success')); ?>', 'success');
            });
        </script>
    <?php endif; ?>
    <?php if(Session::has('error')): ?>
        <script>
            $(document).ready(function() {
                swal('Oops', '<?php echo e(Session::get('error')); ?>', 'error');
            });
        </script>
    <?php endif; ?>
    <?php if(Session::has('warning')): ?>
        <script>
            $(document).ready(function() {
                swal('Warning', '<?php echo e(Session::get('success')); ?>', 'warning');
            });
        </script>
    <?php endif; ?>
    <?php echo $__env->yieldContent('js'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\street_hospitals\resources\views/layouts/admin/default.blade.php ENDPATH**/ ?>